use anyhow::{bail, Result};
use byteorder::{LittleEndian, ReadBytesExt};
use std::io::{Cursor, Read};

pub const MAINNET_MAGIC:[u8;4]=[0x24,0xe9,0x27,0x64];
pub const MAINNET_PORT:u16=8833;
pub const NETWORK:&str="main";

#[derive(Clone,Debug,PartialEq,Eq)]
pub struct BlockHeader{pub version:u32,pub prev:[u8;32],pub merkle:[u8;32],pub time:u32,pub bits:u32,pub nonce:[u8;32],pub solution:Vec<u8>}
#[derive(Clone,Debug,PartialEq,Eq)]
pub struct Block{pub header:BlockHeader,pub txs:Vec<Vec<u8>>}

pub fn read_compact_size(c:&mut Cursor<&[u8]>) -> Result<u64>{let n=c.read_u8()?;match n{0..=252=>Ok(n as u64),253=>Ok(c.read_u16::<LittleEndian>()? as u64),254=>Ok(c.read_u32::<LittleEndian>()? as u64),255=>Ok(c.read_u64::<LittleEndian>()?)}}
pub fn read_bytes(c:&mut Cursor<&[u8]>,max:usize)->Result<Vec<u8>>{let n=read_compact_size(c)? as usize;if n>max{bail!("field too large: {n}")}let mut v=vec![0;n];c.read_exact(&mut v)?;Ok(v)}
pub fn read_block(raw:&[u8])->Result<Block>{let mut c=Cursor::new(raw);let header_start=c.position();let version=c.read_u32::<LittleEndian>()?;let mut prev=[0;32];c.read_exact(&mut prev)?;let mut merkle=[0;32];c.read_exact(&mut merkle)?;let time=c.read_u32::<LittleEndian>()?;let bits=c.read_u32::<LittleEndian>()?;let mut nonce=[0;32];c.read_exact(&mut nonce)?;let solution=read_bytes(&mut c,1344)?;let header_len=c.position()-header_start; if header_len>2048{bail!("header too large")};let n=read_compact_size(&mut c)? as usize;if n>100000{bail!("too many transactions")};let mut txs=Vec::with_capacity(n.min(1024));for _ in 0..n{let tx=read_bytes(&mut c,4*1024*1024)?;txs.push(tx)};if (c.position() as usize)!=raw.len(){bail!("trailing block bytes")};Ok(Block{header:BlockHeader{version,prev,merkle,time,bits,nonce,solution},txs})}
