fn main(){cc::Build::new().cpp(true).file("../../cpp/ycash_consensus_bridge.cpp").include("../../ycash-4.5.0/src").flag_if_supported("-std=c++17").compile("ycash_consensus_bridge");}
