use std::io::{self, Read, Write};
use std::net::{SocketAddr, TcpStream};
use std::time::{Duration, SystemTime, UNIX_EPOCH};

use crate::{decode_header, encode_message, Hash256, MAINNET_MAGIC, PROTOCOL_VERSION};

pub struct NetworkPeer<S> {
    pub stream: S,
    pub peer_addr: SocketAddr,
    pub nonce: u64,
}

pub fn unix_time() -> i64 {
    SystemTime::now().duration_since(UNIX_EPOCH).unwrap_or_default().as_secs() as i64
}

/// Bitcoin/Zcash-compatible CompactSize encoding.
pub fn compact_size(n: u64, out: &mut Vec<u8>) {
    match n {
        0..=252 => out.push(n as u8),
        253..=65535 => { out.push(253); out.extend_from_slice(&(n as u16).to_le_bytes()); }
        65536..=0xffff_ffff => { out.push(254); out.extend_from_slice(&(n as u32).to_le_bytes()); }
        _ => { out.push(255); out.extend_from_slice(&n.to_le_bytes()); }
    }
}

fn write_i64(out:&mut Vec<u8>, n:i64){out.extend_from_slice(&n.to_le_bytes());}
fn write_i32(out:&mut Vec<u8>, n:i32){out.extend_from_slice(&n.to_le_bytes());}
fn write_u64(out:&mut Vec<u8>, n:u64){out.extend_from_slice(&n.to_le_bytes());}

/// Minimal `version` payload. Caller supplies the node's advertised services,
/// address and nonce. Consensus/state are not involved in this handshake.
pub fn version_payload(
    services: u64,
    remote: SocketAddr,
    local: SocketAddr,
    nonce: u64,
    user_agent: &str,
) -> Vec<u8> {
    let mut p=Vec::with_capacity(128);
    write_i32(&mut p, PROTOCOL_VERSION);
    write_u64(&mut p, services);
    write_i64(&mut p, unix_time());
    // net_addr: services, IPv6-mapped IPv4, port BE
    write_u64(&mut p, 0);
    p.extend_from_slice(&[0,0,0,0,0,0,0,0,0,0,0xff,0xff]);
    p.extend_from_slice(&remote.ip().to_string().parse::<std::net::Ipv4Addr>()
        .map(|x|x.octets()).unwrap_or([0,0,0,0]));
    p.extend_from_slice(&remote.port().to_be_bytes());
    write_u64(&mut p, services);
    p.extend_from_slice(&[0,0,0,0,0,0,0,0,0,0,0xff,0xff]);
    p.extend_from_slice(&local.ip().to_string().parse::<std::net::Ipv4Addr>()
        .map(|x|x.octets()).unwrap_or([0,0,0,0]));
    p.extend_from_slice(&local.port().to_be_bytes());
    write_u64(&mut p, nonce);
    compact_size(user_agent.len() as u64,&mut p);
    p.extend_from_slice(user_agent.as_bytes());
    write_i32(&mut p, 0);
    p.push(0);
    p
}

pub fn send_message<S: Write, H: Hash256>(
    stream:&mut S, command:&str, payload:&[u8]
) -> io::Result<()> {
    let m=encode_message::<H>(command,payload)?;
    stream.write_all(&m)
}

pub fn recv_message<S: Read, H: Hash256>(
    stream:&mut S
) -> io::Result<(String,Vec<u8>)> {
    let mut h=[0u8;24];
    stream.read_exact(&mut h)?;
    let (cmd,len,sum)=decode_header::<H>(&h)?;
    let mut payload=vec![0u8;len as usize];
    stream.read_exact(&mut payload)?;
    let actual=H::hash256(&payload);
    if actual[..4] != sum {
        return Err(io::Error::new(io::ErrorKind::InvalidData,"checksum mismatch"));
    }
    Ok((cmd,payload))
}

pub fn connect_with_timeout(addr: SocketAddr, timeout:Duration)->io::Result<TcpStream>{
    let s=TcpStream::connect_timeout(&addr,timeout)?;
    s.set_read_timeout(Some(timeout))?;
    s.set_write_timeout(Some(timeout))?;
    Ok(s)
}

pub fn verack_payload()->[u8;0]{[]}

pub fn getheaders_payload(locator:&[[u8;32]], stop:&[u8;32])->Vec<u8>{
    let mut p=Vec::new();
    write_i32(&mut p,PROTOCOL_VERSION);
    compact_size(locator.len() as u64,&mut p);
    for h in locator { p.extend_from_slice(h); }
    p.extend_from_slice(stop);
    p
}

#[cfg(test)]
mod tests {
    use super::*;
    struct H;
    impl Hash256 for H { fn hash256(_: &[u8])->[u8;32]{[1;32]} }

    #[test]
    fn compact_size_boundaries(){
        let mut b=Vec::new(); compact_size(252,&mut b); assert_eq!(b,vec![252]);
        b.clear(); compact_size(253,&mut b); assert_eq!(b,vec![253,253,0]);
    }
    #[test]
    fn getheaders_contains_locator(){
        let loc=[[2u8;32],[3u8;32]];
        let p=getheaders_payload(&loc,&[0u8;32]);
        assert_eq!(i32::from_le_bytes(p[0..4].try_into().unwrap()),PROTOCOL_VERSION);
        assert_eq!(p[4],2);
    }
}
