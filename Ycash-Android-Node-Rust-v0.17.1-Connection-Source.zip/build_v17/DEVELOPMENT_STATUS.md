# Development Status

Current project line: v0.12 — real Android process + initial live P2P handshake.

Implemented and wired:
- Rust Android node is a workspace member and builds as its own binary.
- Android foreground service launches the bundled ARM64 node process.
- Node exposes localhost status telemetry.
- Node resolves `YCASH_PEER` or defaults to `seed.ycash.xyz:8833`.
- Node sends `version`, receives `version`, sends/receives `verack`, and answers `ping` with `pong`.
- Peer advertised start height is surfaced as target/header telemetry.

Not yet complete:
- Header locator construction and validated header synchronization.
- Block download, consensus validation and persistent main-chain commit.
- Full peer discovery/peer manager and transaction relay.

These are deliberately not reported as complete until tested against Ycash mainnet and a reference node.


## v0.17 networking/logo update

- DNS seed resolution failure is recoverable via the fixed Ycash mainnet seeds from Ycash 4.5.0 `pnSeed6_main`.
- The Android network test tries DNS-resolved peers and fixed-seed fallbacks.
- The native node retries peer discovery and connection instead of stopping after one DNS failure.
- App launcher icon and in-app logo use `ycash_logo.png`.
- This update does **not** claim full header/block synchronization; the existing prototype still requires a validated chain locator and consensus-backed sync pipeline before sync is enabled.
