# Development Status

Current project line: v0.11 — Live UI telemetry.

Implemented/scaffolded:
- Stages 1–11: iterative foundation through live telemetry wiring.

Remaining:
- Stages 12–21: see `REMAINING_STAGES.md`.

Important:
The remaining stages are requirements, not claims of implementation. Each must pass its
defined exit criteria before being marked complete.
