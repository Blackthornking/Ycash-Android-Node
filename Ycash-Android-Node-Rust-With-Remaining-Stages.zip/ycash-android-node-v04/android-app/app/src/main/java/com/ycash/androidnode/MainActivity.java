package com.ycash.androidnode;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.widget.*;
import java.net.*;
import java.io.*;
import org.json.JSONObject;

public class MainActivity extends Activity {
    TextView status, peer, height, sync, log, headersHeight;
    Handler handler = new Handler();
    boolean running = false;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_main);
        status=findViewById(R.id.status);
        peer=findViewById(R.id.peer);
        height=findViewById(R.id.height);
        sync=findViewById(R.id.sync);
        log=findViewById(R.id.log);

        findViewById(R.id.start).setOnClickListener(v -> {
            running=true;
            status.setText("● RUNNING — LOCAL NODE");
            log.setText("Log: node lifecycle requested");
            pollStatus();
        });

        findViewById(R.id.stop).setOnClickListener(v -> {
            running=false;
            status.setText("● STOPPED");
            sync.setText("Sync: stopped");
            log.setText("Log: node stopped");
        });

        findViewById(R.id.test).setOnClickListener(v -> testNetwork());
    }

    private void pollStatus() {
        if (!running) return;
        new Thread(() -> {
            try {
                URL u=new URL("http://127.0.0.1:8834/status");
                HttpURLConnection c=(HttpURLConnection)u.openConnection();
                c.setConnectTimeout(1500);
                c.setReadTimeout(1500);
                c.setRequestMethod("GET");
                if(c.getResponseCode()==200) {
                    BufferedReader br=new BufferedReader(new InputStreamReader(c.getInputStream()));
                    StringBuilder s=new StringBuilder(); String line;
                    while((line=br.readLine())!=null) s.append(line);
                    JSONObject j=new JSONObject(s.toString());
                    runOnUiThread(() -> applyStatus(j));
                }
                c.disconnect();
            } catch(Exception ignored) {
                // Keep the last real values when the local API is temporarily unavailable.
            }
            handler.postDelayed(this::pollStatus, 2000);
        }).start();
    }

    private void applyStatus(JSONObject j) {
        try {
            status.setText("● "+j.optString("status","UNKNOWN").toUpperCase());
            peer.setText("Peers: "+j.optInt("peers",0));
            height.setText("Block height: "+j.optLong("height",-1));
            headersHeight.setText("Headers height: "+j.optLong("headers_height",-1));
            sync.setText("Sync: "+j.optString("sync","unknown"));
            log.setText("Log: "+j.optString("message","status updated"));
        } catch(Exception ignored) {}
    }

    private void testNetwork() {
        status.setText("● CONNECTING");
        log.setText("Log: testing Ycash mainnet TCP port 8833…");
        new Thread(() -> {
            try(Socket s=new Socket()) {
                s.connect(new InetSocketAddress("seed.ycash.xyz",8833),10000);
                runOnUiThread(() -> {
                    status.setText("● NETWORK REACHABLE");
                    log.setText("Log: TCP connection to Ycash mainnet succeeded");
                });
            } catch(Exception e) {
                runOnUiThread(() -> {
                    status.setText("● CONNECTION FAILED");
                    log.setText("Log: "+e.getClass().getSimpleName()+": "+e.getMessage());
                });
            }
        }).start();
    }
}
