use std::{ffi::c_char};
use anyhow::{bail,Result};
use ycash_chain::Block;

#[derive(Debug,Clone,PartialEq,Eq)]
pub enum ConsensusError{Invalid(String),Bridge(String),Contextual(String)}
extern "C"{fn ycash_check_block_mainnet(data:*const u8,len:usize,check_pow:i32,check_merkle:i32,check_transactions:i32,reason:*mut c_char,reason_len:usize)->i32;fn ycash_check_tx_mainnet(data:*const u8,len:usize,reason:*mut c_char,reason_len:usize)->i32;}
fn reason(buf:&[i8])->String{let bytes:Vec<u8>=buf.iter().take_while(|&&x|x!=0).map(|&x|x as u8).collect();String::from_utf8_lossy(&bytes).into_owned()}
pub fn check_block_strict(bytes:&[u8])->Result<(),ConsensusError>{if bytes.is_empty(){return Err(ConsensusError::Invalid("empty block".into()))}let mut out=[0i8;256];let rc=unsafe{ycash_check_block_mainnet(bytes.as_ptr(),bytes.len(),1,1,1,out.as_mut_ptr(),out.len())};match rc{1=>Ok(()),0=>Err(ConsensusError::Invalid(reason(&out))),_=>Err(ConsensusError::Bridge(reason(&out)))}}
pub fn check_transaction_strict(bytes:&[u8])->Result<(),ConsensusError>{if bytes.is_empty(){return Err(ConsensusError::Invalid("empty transaction".into()))}let mut out=[0i8;256];let rc=unsafe{ycash_check_tx_mainnet(bytes.as_ptr(),bytes.len(),out.as_mut_ptr(),out.len())};match rc{1=>Ok(()),0=>Err(ConsensusError::Invalid(reason(&out))),_=>Err(ConsensusError::Bridge(reason(&out)))}}
#[derive(Debug,Clone,Copy)]pub struct Context{pub height:u64,pub prev_height:u64,pub median_time_past:u32}
pub fn check_context(block:&Block,ctx:Context)->Result<(),ConsensusError>{if ctx.height!=ctx.prev_height+1{return Err(ConsensusError::Contextual("non-contiguous height".into()))}if block.header.time<=ctx.median_time_past{return Err(ConsensusError::Contextual("block time not greater than median-time-past".into()))}Ok(())}
pub fn validate_for_commit(raw:&[u8],ctx:Context)->Result<Block,ConsensusError>{check_block_strict(raw)?;let block=ycash_chain::read_block(raw).map_err(|e|ConsensusError::Invalid(e.to_string()))?;check_context(&block,ctx)?;for tx in &block.txs{check_transaction_strict(tx)?;}Ok(block)}
