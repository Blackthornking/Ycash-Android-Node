use anyhow::{bail,Result};
use rusqlite::{params,Connection};
use std::path::Path;

#[derive(Debug,Clone)]
pub struct Tip{pub hash:Vec<u8>,pub height:u64,pub work:[u8;32]}
pub struct State{db:Connection}
impl State{
 pub fn open(p:impl AsRef<Path>)->Result<Self>{let db=Connection::open(p)?;db.execute_batch("PRAGMA journal_mode=WAL; PRAGMA foreign_keys=ON; CREATE TABLE IF NOT EXISTS meta(k TEXT PRIMARY KEY,v BLOB NOT NULL); CREATE TABLE IF NOT EXISTS blocks(hash BLOB PRIMARY KEY,height INTEGER NOT NULL,prev BLOB NOT NULL,work BLOB NOT NULL,raw BLOB NOT NULL,main_chain INTEGER NOT NULL DEFAULT 0); CREATE INDEX IF NOT EXISTS blocks_height ON blocks(height); CREATE INDEX IF NOT EXISTS blocks_prev ON blocks(prev); CREATE TABLE IF NOT EXISTS undo(block_hash BLOB PRIMARY KEY,height INTEGER NOT NULL,undo BLOB NOT NULL); CREATE TABLE IF NOT EXISTS txs(txid BLOB PRIMARY KEY,block_hash BLOB NOT NULL,raw BLOB NOT NULL); CREATE TABLE IF NOT EXISTS nullifiers(n BLOB PRIMARY KEY,block_hash BLOB NOT NULL); CREATE TABLE IF NOT EXISTS utxos(txid BLOB NOT NULL,vout INTEGER NOT NULL,value BLOB NOT NULL,script BLOB NOT NULL,block_hash BLOB NOT NULL,PRIMARY KEY(txid,vout));")?;Ok(Self{db})}
 pub fn put_block(&self,height:u64,hash:&[u8],prev:&[u8],work:&[u8],raw:&[u8])->Result<()>{if hash.len()!=32||prev.len()!=32||work.len()!=32{bail!("invalid hash/work length")};self.db.execute("INSERT OR REPLACE INTO blocks(hash,height,prev,work,raw,main_chain) VALUES(?1,?2,?3,?4,?5,0)",params![hash,height,prev,work,raw])?;Ok(())}
 pub fn set_tip(&self,tip:&Tip)->Result<()>{let tx=self.db.unchecked_transaction()?;tx.execute("UPDATE blocks SET main_chain=0 WHERE main_chain=1",[])?;tx.execute("UPDATE blocks SET main_chain=1 WHERE hash=?1",params![&tip.hash])?;tx.execute("INSERT OR REPLACE INTO meta(k,v) VALUES('tip_hash',?1)",params![&tip.hash])?;tx.execute("INSERT OR REPLACE INTO meta(k,v) VALUES('tip_height',?1)",params![tip.height.to_le_bytes().to_vec()])?;tx.commit()?;Ok(())}
 pub fn tip_height(&self)->Result<Option<u64>>{let r=self.db.query_row("SELECT MAX(height) FROM blocks WHERE main_chain=1",[],|r|r.get::<_,Option<i64>>(0))?;Ok(r.map(|x|x as u64))}
 pub fn has_block(&self,hash:&[u8])->Result<bool>{Ok(self.db.query_row("SELECT EXISTS(SELECT 1 FROM blocks WHERE hash=?1)",params![hash],|r|r.get(0))?)}
}
