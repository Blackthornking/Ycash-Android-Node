use std::io::{Read, Write};
use std::net::TcpListener;
use std::sync::{Arc, RwLock};
use std::thread;
mod runtime;
use runtime::{LiveNodeState, SharedState};

fn esc(s:&str)->String { s.replace('\\',"\\\\").replace('"',"\\\"") }
fn json(s:&LiveNodeState)->String {
    let status=if s.running {"running"} else {"stopped"};
    format!(r#"{{"status":"{}","peers":{},"height":{},"headers_height":{},"sync":"{}","message":"{}"}}"#,
        status,s.peers,s.local_height,s.headers_height,esc(&s.sync_text()),esc(&s.message))
}
fn serve(mut stream:std::net::TcpStream,state:SharedState) {
    let mut b=[0u8;2048]; let _=stream.read(&mut b);
    let req=String::from_utf8_lossy(&b);
    if req.lines().next().unwrap_or("").starts_with("GET /status ") {
        let body=json(&state.read().unwrap());
        let r=format!("HTTP/1.1 200 OK\r\nContent-Type: application/json\r\nCache-Control: no-store\r\nContent-Length: {}\r\nConnection: close\r\n\r\n{}",
            body.len(),body);
        let _=stream.write_all(r.as_bytes());
    } else {
        let body=r#"{"error":"not found"}"#;
        let r=format!("HTTP/1.1 404 Not Found\r\nContent-Type: application/json\r\nContent-Length: {}\r\nConnection: close\r\n\r\n{}",
            body.len(),body);
        let _=stream.write_all(r.as_bytes());
    }
}
fn start_api(state:SharedState)->std::io::Result<()> {
    let listener=TcpListener::bind(("127.0.0.1",8834))?;
    thread::spawn(move|| for s in listener.incoming() {
        if let Ok(s)=s { let st=state.clone(); thread::spawn(move||serve(s,st)); }
    });
    Ok(())
}
fn main() {
    let state=Arc::new(RwLock::new(LiveNodeState {
        running:true, ..Default::default()
    }));
    if let Err(e)=start_api(state.clone()) { eprintln!("API failed: {e}"); return; }
    println!("Ycash Android Node v0.11");
    println!("Live UI API: http://127.0.0.1:8834/status");
    println!("Telemetry is derived from live node state; no hard-coded chain height.");
    loop { thread::park(); }
}
