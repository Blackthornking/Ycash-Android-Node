use sha2::{Digest, Sha256};
use std::io::{Read, Write};
use std::net::{TcpListener, TcpStream, ToSocketAddrs};
use std::sync::{Arc, RwLock};
use std::thread;
use std::time::Duration;
use ycash_network::runtime::{connect_with_timeout, getheaders_payload, unix_time, version_payload};
use ycash_network::{decode_header, encode_message, Hash256, MAINNET_MAGIC, PROTOCOL_VERSION};

mod runtime;
use runtime::{LiveNodeState, SharedState};

struct DoubleSha;
impl Hash256 for DoubleSha {
    fn hash256(data: &[u8]) -> [u8; 32] {
        let a = Sha256::digest(data);
        let b = Sha256::digest(a);
        let mut out = [0u8; 32];
        out.copy_from_slice(&b);
        out
    }
}

fn esc(s: &str) -> String { s.replace('\\', "\\\\").replace('"', "\\\"") }
fn json(s: &LiveNodeState) -> String {
    format!(r#"{{"status":"{}","peers":{},"height":{},"headers_height":{},"sync":"{}","message":"{}"}}"#,
        if s.running { "running" } else { "stopped" }, s.peers, s.local_height,
        s.headers_height, esc(&s.sync_text()), esc(&s.message))
}
fn serve(mut stream: TcpStream, state: SharedState) {
    let mut b = [0u8; 2048]; let _ = stream.read(&mut b);
    let req = String::from_utf8_lossy(&b);
    let (code, body) = if req.lines().next().unwrap_or("").starts_with("GET /status ") {
        ("200 OK", json(&state.read().unwrap()))
    } else { ("404 Not Found", r#"{"error":"not found"}"#.into()) };
    let r = format!("HTTP/1.1 {code}\r\nContent-Type: application/json\r\nCache-Control: no-store\r\nContent-Length: {}\r\nConnection: close\r\n\r\n{}", body.len(), body);
    let _ = stream.write_all(r.as_bytes());
}
fn start_api(state: SharedState) -> std::io::Result<()> {
    let listener = TcpListener::bind(("127.0.0.1", 8834))?;
    thread::spawn(move || for s in listener.incoming() {
        if let Ok(s) = s { let st = state.clone(); thread::spawn(move || serve(s, st)); }
    });
    Ok(())
}

fn read_message(stream: &mut TcpStream) -> std::io::Result<(String, Vec<u8>)> {
    let mut h = [0u8; 24]; stream.read_exact(&mut h)?;
    let (cmd, len, checksum) = decode_header::<DoubleSha>(&h)?;
    if len as usize > 4 * 1024 * 1024 { return Err(std::io::Error::new(std::io::ErrorKind::InvalidData, "message too large")); }
    let mut p = vec![0u8; len as usize]; stream.read_exact(&mut p)?;
    let got = DoubleSha::hash256(&p);
    if got[..4] != checksum { return Err(std::io::Error::new(std::io::ErrorKind::InvalidData, "checksum mismatch")); }
    Ok((cmd, p))
}
fn send(stream: &mut TcpStream, cmd: &str, payload: &[u8]) -> std::io::Result<()> {
    stream.write_all(&encode_message::<DoubleSha>(cmd, payload)?)
}
fn advertised_height(version: &[u8]) -> Option<u64> {
    // version payload: version(4), services(8), time(8), addr_recv(26),
    // addr_from(26), nonce(8), user-agent(var), start_height(4), relay(1)
    if version.len() < 80 { return None; }
    let mut i = 4 + 8 + 8 + 26 + 26 + 8;
    let first = *version.get(i)?;
    let ua_len = match first { 0..=252 => first as usize,
        253 => { if version.len()<i+3{return None}; u16::from_le_bytes([version[i+1],version[i+2]]) as usize + 3 },
        254 => { if version.len()<i+5{return None}; u32::from_le_bytes(version[i+1..i+5].try_into().ok()?) as usize + 5 },
        _ => return None };
    if first <= 252 { i += 1 + ua_len; } else { i += ua_len; }
    if version.len() < i + 4 { return None; }
    Some(i32::from_le_bytes(version[i..i+4].try_into().ok()?).max(0) as u64)
}
fn peer_loop(addr: std::net::SocketAddr, state: SharedState) -> bool {
    state.write().unwrap().message = format!("connecting to {addr}");
    let mut s = match connect_with_timeout(addr, Duration::from_secs(10)) {
        Ok(s) => s,
        Err(e) => {
            state.write().unwrap().message = format!("peer connect failed {addr}: {e}");
            return false;
        }
    };

    let local = "0.0.0.0:0".parse().unwrap();
    let version = version_payload(
        0,
        addr,
        local,
        unix_time() as u64 ^ std::process::id() as u64,
        "/YcashAndroid:0.17/",
    );

    if let Err(e) = send(&mut s, "version", &version) {
        state.write().unwrap().message = format!("version send failed {addr}: {e}");
        return false;
    }

    let mut got_version = false;
    let mut got_verack = false;

    for _ in 0..12 {
        match read_message(&mut s) {
            Ok((cmd, payload)) if cmd == "version" => {
                got_version = true;
                let h = advertised_height(&payload);
                let mut st = state.write().unwrap();
                st.peers = 1;
                st.target_height = h;
                st.headers_height = h.unwrap_or(st.headers_height);
                st.message = format!("handshake: connected to {addr} (peer height {:?})", h);
                let _ = send(&mut s, "verack", &[]);
            }
            Ok((cmd, _)) if cmd == "verack" => {
                got_verack = true;
                state.write().unwrap().message = format!("Ycash P2P handshake complete: {addr}");
            }
            Ok((cmd, payload)) if cmd == "ping" => {
                let _ = send(&mut s, "pong", &payload);
            }
            Ok((_cmd, _)) => {}
            Err(e) => {
                state.write().unwrap().message = format!("peer handshake failed {addr}: {e}");
                return false;
            }
        }
        if got_version && got_verack {
            break;
        }
    }

    if !(got_version && got_verack) {
        state.write().unwrap().message = format!("incomplete handshake with {addr}");
        return false;
    }

    // Keep the connection alive for peer availability/telemetry. Full
    // header/block synchronization is not faked here; it requires a
    // validated chain locator and consensus-backed block commit pipeline.
    let _ = s.set_read_timeout(Some(Duration::from_secs(30)));
    loop {
        match read_message(&mut s) {
            Ok((cmd, payload)) if cmd == "ping" => {
                if send(&mut s, "pong", &payload).is_err() {
                    break;
                }
            }
            Ok((_cmd, _)) => {}
            Err(_) => break,
        }
    }

    let mut st = state.write().unwrap();
    st.peers = 0;
    st.message = format!("peer {addr} disconnected; retrying");
    false
}

fn peer_candidates() -> Vec<std::net::SocketAddr> {
    // These fixed seeds are taken from Ycash 4.5.0's pnSeed6_main.
    const FIXED_SEEDS: &[&str] = &["3.130.144.65:8833", "13.126.58.237:8833"];

    let mut out = Vec::new();

    // Optional user override. Multiple addresses may be supplied separated by
    // commas or semicolons. This is useful for testing a private/full node.
    if let Ok(value) = std::env::var("YCASH_PEER") {
        for item in value.split([',', ';']) {
            let item = item.trim();
            if item.is_empty() {
                continue;
            }
            if let Ok(addrs) = item.to_socket_addrs() {
                out.extend(addrs);
            }
        }
    }

    // DNS seed is preferred, but failure must never prevent fixed-seed fallback.
    match "seed.ycash.xyz:8833".to_socket_addrs() {
        Ok(addrs) => out.extend(addrs),
        Err(e) => eprintln!("Ycash DNS seed resolution failed: {e}; using fixed seeds"),
    }

    for fixed in FIXED_SEEDS {
        if let Ok(mut addrs) = fixed.to_socket_addrs() {
            if let Some(addr) = addrs.next() {
                out.push(addr);
            }
        }
    }

    // Deduplicate while preserving preference order.
    let mut unique = Vec::new();
    for addr in out {
        if !unique.contains(&addr) {
            unique.push(addr);
        }
    }
    unique
}

fn peer_supervisor(state: SharedState) {
    loop {
        let candidates = peer_candidates();
        if candidates.is_empty() {
            state.write().unwrap().message =
                "no Ycash peers resolved; retrying in 10 seconds".into();
            thread::sleep(Duration::from_secs(10));
            continue;
        }

        let mut connected = false;
        for addr in candidates {
            state.write().unwrap().message = format!("trying Ycash peer {addr}");
            if peer_loop(addr, state.clone()) {
                connected = true;
                break;
            }
        }

        if !connected {
            state.write().unwrap().message =
                "all Ycash peers failed; retrying discovery in 10 seconds".into();
            thread::sleep(Duration::from_secs(10));
        }
    }
}

fn main() {
    let state = Arc::new(RwLock::new(LiveNodeState { running:true, ..Default::default() }));
    if let Err(e)=start_api(state.clone()) { eprintln!("API failed: {e}"); return; }
    println!("Ycash Android Node v0.17");
    println!("Live UI API: http://127.0.0.1:8834/status");
    let st=state.clone();
    thread::spawn(move || peer_supervisor(st));
    loop { thread::park(); }
}
