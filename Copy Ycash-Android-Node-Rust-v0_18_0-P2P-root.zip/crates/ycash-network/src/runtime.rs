use std::io::{self, Read, Write};
use std::net::{IpAddr, Ipv4Addr, SocketAddr, TcpStream};
use std::time::{Duration, SystemTime, UNIX_EPOCH};
use crate::{decode_header, encode_message, Hash256, PROTOCOL_VERSION};

pub const NODE_NETWORK: u64 = 1;

pub fn unix_time() -> i64 { SystemTime::now().duration_since(UNIX_EPOCH).unwrap_or_default().as_secs() as i64 }

pub fn compact_size(n: u64, out: &mut Vec<u8>) { match n { 0..=252=>out.push(n as u8),253..=65535=>{out.push(253);out.extend_from_slice(&(n as u16).to_le_bytes())},65536..=0xffff_ffff=>{out.push(254);out.extend_from_slice(&(n as u32).to_le_bytes())},_=>{out.push(255);out.extend_from_slice(&n.to_le_bytes())} } }

pub fn read_compact_size(data:&[u8], i:&mut usize)->io::Result<u64>{
    let b=*data.get(*i).ok_or_else(||io::Error::new(io::ErrorKind::UnexpectedEof,"compactsize"))?; *i+=1;
    match b {0..=252=>Ok(b as u64),253=>{let x=data.get(*i..*i+2).ok_or_else(||io::Error::new(io::ErrorKind::UnexpectedEof,"compactsize"))?;*i+=2;Ok(u16::from_le_bytes([x[0],x[1]]) as u64)},254=>{let x=data.get(*i..*i+4).ok_or_else(||io::Error::new(io::ErrorKind::UnexpectedEof,"compactsize"))?;*i+=4;Ok(u32::from_le_bytes(x.try_into().unwrap()) as u64)},255=>{let x=data.get(*i..*i+8).ok_or_else(||io::Error::new(io::ErrorKind::UnexpectedEof,"compactsize"))?;*i+=8;Ok(u64::from_le_bytes(x.try_into().unwrap()))}}
}

fn write_i64(o:&mut Vec<u8>,n:i64){o.extend_from_slice(&n.to_le_bytes())}
fn write_i32(o:&mut Vec<u8>,n:i32){o.extend_from_slice(&n.to_le_bytes())}
fn write_u64(o:&mut Vec<u8>,n:u64){o.extend_from_slice(&n.to_le_bytes())}

pub fn version_payload(services:u64,remote:SocketAddr,local:SocketAddr,nonce:u64,user_agent:&str)->Vec<u8>{
    let mut p=Vec::with_capacity(256); write_i32(&mut p,PROTOCOL_VERSION); write_u64(&mut p,services); write_i64(&mut p,unix_time());
    write_u64(&mut p,0); p.extend_from_slice(&ipv6_bytes(remote.ip())); p.extend_from_slice(&remote.port().to_be_bytes());
    write_u64(&mut p,services); p.extend_from_slice(&ipv6_bytes(local.ip())); p.extend_from_slice(&local.port().to_be_bytes());
    write_u64(&mut p,nonce); compact_size(user_agent.len() as u64,&mut p); p.extend_from_slice(user_agent.as_bytes()); write_i32(&mut p,0); p.push(1); p
}
fn ipv6_bytes(ip:IpAddr)->[u8;16]{match ip {IpAddr::V4(v)=>{let mut x=[0u8;16];x[10]=0xff;x[11]=0xff;x[12..].copy_from_slice(&v.octets());x},IpAddr::V6(v)=>v.octets()}}

pub fn advertised_height(version:&[u8])->Option<u64>{
    if version.len()<80{return None} let mut i=4+8+8+26+26+8; let n=read_compact_size(version,&mut i).ok()? as usize; i=i.checked_add(n)?; if version.len()<i+4{return None}; Some(i32::from_le_bytes(version[i..i+4].try_into().ok()?).max(0) as u64)
}

pub fn parse_addr_message(payload:&[u8], max:usize)->io::Result<Vec<SocketAddr>>{
    let mut i=0; let count=read_compact_size(payload,&mut i)? as usize; if count>max{return Err(io::Error::new(io::ErrorKind::InvalidData,"too many addresses"))}; let mut out=Vec::with_capacity(count);
    for _ in 0..count { if i+4+8+16+2>payload.len(){return Err(io::Error::new(io::ErrorKind::UnexpectedEof,"addr"))}; i+=4; i+=8; let ip=&payload[i..i+16]; i+=16; let port=u16::from_be_bytes([payload[i],payload[i+1]]); i+=2; let mut a=[0u8;4]; if ip[..12]==[0,0,0,0,0,0,0,0,0,0,0,0] {continue} if ip[..12]==[0,0,0,0,0,0,0,0,0,0,0xff,0xff]{a.copy_from_slice(&ip[12..]);out.push(SocketAddr::new(IpAddr::V4(Ipv4Addr::from(a)),port));} }
    Ok(out)
}

pub fn send_message<S:Write,H:Hash256>(stream:&mut S,command:&str,payload:&[u8])->io::Result<()>{stream.write_all(&encode_message::<H>(command,payload)?) }
pub fn recv_message<S:Read,H:Hash256>(stream:&mut S)->io::Result<(String,Vec<u8>)>{let mut h=[0u8;24];stream.read_exact(&mut h)?;let (cmd,len,sum)=decode_header::<H>(&h)?;let mut p=vec![0u8;len as usize];stream.read_exact(&mut p)?;if H::hash256(&p)[..4]!=sum{return Err(io::Error::new(io::ErrorKind::InvalidData,"checksum mismatch"))}Ok((cmd,p))}
pub fn connect_with_timeout(addr:SocketAddr,timeout:Duration)->io::Result<TcpStream>{let s=TcpStream::connect_timeout(&addr,timeout)?;s.set_read_timeout(Some(timeout))?;s.set_write_timeout(Some(timeout))?;Ok(s)}
pub fn getaddr_payload()->[u8;0]{[]}
pub fn verack_payload()->[u8;0]{[]}
pub fn getheaders_payload(locator:&[[u8;32]],stop:&[u8;32])->Vec<u8>{let mut p=Vec::new();write_i32(&mut p,PROTOCOL_VERSION);compact_size(locator.len() as u64,&mut p);for h in locator{p.extend_from_slice(h)}p.extend_from_slice(stop);p}
