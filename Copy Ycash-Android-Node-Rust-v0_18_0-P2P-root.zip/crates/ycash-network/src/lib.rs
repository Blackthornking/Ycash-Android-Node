//! Phase 7: Ycash-compatible wire/sync transport primitives.
//!
//! This crate deliberately separates untrusted network transport from consensus.
//! A caller must validate headers/blocks before committing them to chain state.

pub mod status;
pub mod runtime;

use std::collections::{HashMap, HashSet, VecDeque};
use std::io;

pub const MAINNET_MAGIC: [u8; 4] = [0x24, 0xe9, 0x27, 0x64];
pub const DEFAULT_PORT: u16 = 8833;
pub const PROTOCOL_VERSION: i32 = 270_013;
pub const MAX_MESSAGE_SIZE: usize = 4 * 1024 * 1024;

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct Message {
    pub command: [u8; 12],
    pub payload: Vec<u8>,
}

fn command_bytes(command: &str) -> [u8; 12] {
    let mut out = [0u8; 12];
    let b = command.as_bytes();
    let n = b.len().min(12);
    out[..n].copy_from_slice(&b[..n]);
    out
}

/// Double-SHA256 checksum. Kept behind a tiny trait so the node can plug in
/// the project's canonical Ycash hash implementation.
pub trait Hash256 {
    fn hash256(data: &[u8]) -> [u8; 32];
}

pub fn encode_message<H: Hash256>(command: &str, payload: &[u8]) -> Result<Vec<u8>, io::Error> {
    if payload.len() > MAX_MESSAGE_SIZE {
        return Err(io::Error::new(io::ErrorKind::InvalidInput, "payload too large"));
    }
    let checksum = H::hash256(payload);
    let mut out = Vec::with_capacity(24 + payload.len());
    out.extend_from_slice(&MAINNET_MAGIC);
    out.extend_from_slice(&command_bytes(command));
    out.extend_from_slice(&(payload.len() as u32).to_le_bytes());
    out.extend_from_slice(&checksum[..4]);
    out.extend_from_slice(payload);
    Ok(out)
}

pub fn decode_header<H: Hash256>(header: &[u8; 24]) -> Result<(String, u32, [u8; 4]), io::Error> {
    if header[..4] != MAINNET_MAGIC {
        return Err(io::Error::new(io::ErrorKind::InvalidData, "bad network magic"));
    }
    let len = u32::from_le_bytes(header[16..20].try_into().unwrap());
    if len as usize > MAX_MESSAGE_SIZE {
        return Err(io::Error::new(io::ErrorKind::InvalidData, "message too large"));
    }
    let end = header[12..16].iter().position(|x| *x == 0).unwrap_or(12);
    let command = String::from_utf8(header[12..12+end].to_vec())
        .map_err(|_| io::Error::new(io::ErrorKind::InvalidData, "invalid command"))?;
    let mut sum=[0u8;4]; sum.copy_from_slice(&header[20..24]);
    Ok((command,len,sum))
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum PeerState { Disconnected, Connecting, Handshaking, Ready, Banned }

#[derive(Clone, Debug)]
pub struct Peer {
    pub id: u64,
    pub addr: String,
    pub state: PeerState,
    pub score: i32,
    pub failures: u32,
}

#[derive(Default)]
pub struct PeerManager {
    peers: HashMap<u64, Peer>,
    banned: HashSet<String>,
}

impl PeerManager {
    pub fn add(&mut self, peer: Peer) -> bool {
        if self.banned.contains(&peer.addr) { return false; }
        self.peers.insert(peer.id, peer).is_none()
    }

    pub fn penalize(&mut self, id: u64, points: i32) {
        if let Some(p)=self.peers.get_mut(&id) {
            p.score -= points;
            p.failures = p.failures.saturating_add(1);
        }
    }

    pub fn ready(&self) -> Vec<&Peer> {
        self.peers.values().filter(|p| p.state == PeerState::Ready && !self.banned.contains(&p.addr)).collect()
    }

    pub fn ban(&mut self, id: u64) {
        if let Some(p)=self.peers.get_mut(&id) {
            p.state=PeerState::Banned;
            self.banned.insert(p.addr.clone());
        }
    }
}

#[derive(Default)]
pub struct HeaderSync {
    locators: Vec<[u8;32]>,
    pending: VecDeque<u64>,
}

impl HeaderSync {
    pub fn new(locator: Vec<[u8;32]>) -> Self { Self { locators: locator, ..Default::default() } }
    pub fn locators(&self) -> &[[u8;32]] { &self.locators }
    pub fn schedule(&mut self, peer: u64) { self.pending.push_back(peer); }
    pub fn next(&mut self) -> Option<u64> { self.pending.pop_front() }
}

#[cfg(test)]
mod tests {
    use super::*;

    struct H;
    impl Hash256 for H { fn hash256(_: &[u8])->[u8;32]{[7u8;32]} }

    #[test]
    fn encodes_ycash_mainnet_header() {
        let m=encode_message::<H>("ping",&[1,2,3]).unwrap();
        assert_eq!(&m[..4], &MAINNET_MAGIC);
        assert_eq!(&m[12..16], b"ping");
        assert_eq!(u32::from_le_bytes(m[16..20].try_into().unwrap()),3);
    }

    #[test]
    fn rejects_wrong_magic() {
        let mut h=[0u8;24]; h[12..16].copy_from_slice(b"ping");
        assert!(decode_header::<H>(&h).is_err());
    }

    #[test]
    fn peer_penalty_and_ban() {
        let mut p=PeerManager::default();
        p.add(Peer{id:1,addr:"127.0.0.1:8833".into(),state:PeerState::Ready,score:0,failures:0});
        p.penalize(1,10);
        p.ban(1);
        assert!(p.ready().is_empty());
    }
}
