use sha2::{Digest, Sha256};
use std::io::{Read, Write};
use std::net::{SocketAddr, TcpListener, TcpStream, ToSocketAddrs};
use std::sync::{Arc, RwLock};
use std::thread;
use std::time::Duration;
use ycash_network::runtime::{connect_with_timeout, unix_time, version_payload, advertised_height, parse_addr_message};
use ycash_network::PROTOCOL_VERSION;
use ycash_network::{decode_header, encode_message, Hash256};

mod runtime;
use runtime::{LiveNodeState, SharedState};

struct DoubleSha;
impl Hash256 for DoubleSha {
    fn hash256(data: &[u8]) -> [u8; 32] {
        let a = Sha256::digest(data);
        let b = Sha256::digest(a);
        let mut out = [0u8; 32];
        out.copy_from_slice(&b);
        out
    }
}

fn esc(s: &str) -> String { s.replace('\\', "\\\\").replace('"', "\\\"") }
fn json(s: &LiveNodeState) -> String {
    format!(r#"{{"status":"{}","peers":{},"height":{},"headers_height":{},"sync":"{}","connection_source":"{}","connection_endpoint":"{}","connection_detail":"{}","message":"{}"}}"#,
        if s.running { "running" } else { "stopped" },
        s.peers,
        s.local_height,
        s.headers_height,
        esc(&s.sync_text()),
        esc(&s.connection_source),
        esc(&s.connection_endpoint),
        esc(&s.connection_detail),
        esc(&s.message))
}
fn serve(mut stream: TcpStream, state: SharedState) {
    let mut b = [0u8; 2048]; let _ = stream.read(&mut b);
    let req = String::from_utf8_lossy(&b);
    let (code, body) = if req.lines().next().unwrap_or("").starts_with("GET /status ") {
        ("200 OK", json(&state.read().unwrap()))
    } else { ("404 Not Found", r#"{"error":"not found"}"#.into()) };
    let r = format!("HTTP/1.1 {code}\r\nContent-Type: application/json\r\nCache-Control: no-store\r\nContent-Length: {}\r\nConnection: close\r\n\r\n{}", body.len(), body);
    let _ = stream.write_all(r.as_bytes());
}
fn start_api(state: SharedState) -> std::io::Result<()> {
    let listener = TcpListener::bind(("127.0.0.1", 8834))?;
    thread::spawn(move || for s in listener.incoming() {
        if let Ok(s) = s { let st = state.clone(); thread::spawn(move || serve(s, st)); }
    });
    Ok(())
}

fn read_message(stream: &mut TcpStream) -> std::io::Result<(String, Vec<u8>)> {
    let mut h = [0u8; 24]; stream.read_exact(&mut h)?;
    let (cmd, len, checksum) = decode_header::<DoubleSha>(&h)?;
    if len as usize > 4 * 1024 * 1024 { return Err(std::io::Error::new(std::io::ErrorKind::InvalidData, "message too large")); }
    let mut p = vec![0u8; len as usize]; stream.read_exact(&mut p)?;
    let got = DoubleSha::hash256(&p);
    if got[..4] != checksum { return Err(std::io::Error::new(std::io::ErrorKind::InvalidData, "checksum mismatch")); }
    Ok((cmd, p))
}
fn send(stream: &mut TcpStream, cmd: &str, payload: &[u8]) -> std::io::Result<()> {
    stream.write_all(&encode_message::<DoubleSha>(cmd, payload)?)
}
fn advertised_height(version: &[u8]) -> Option<u64> {
    // version payload: version(4), services(8), time(8), addr_recv(26),
    // addr_from(26), nonce(8), user-agent(var), start_height(4), relay(1)
    if version.len() < 80 { return None; }
    let mut i = 4 + 8 + 8 + 26 + 26 + 8;
    let first = *version.get(i)?;
    let ua_len = match first { 0..=252 => first as usize,
        253 => { if version.len()<i+3{return None}; u16::from_le_bytes([version[i+1],version[i+2]]) as usize + 3 },
        254 => { if version.len()<i+5{return None}; u32::from_le_bytes(version[i+1..i+5].try_into().ok()?) as usize + 5 },
        _ => return None };
    if first <= 252 { i += 1 + ua_len; } else { i += ua_len; }
    if version.len() < i + 4 { return None; }
    Some(i32::from_le_bytes(version[i..i+4].try_into().ok()?).max(0) as u64)
}
#[derive(Clone, Debug)]
struct PeerCandidate {
    addr: SocketAddr,
    source: String,
}


#[derive(Clone, Debug)]
struct PeerCandidate { addr: SocketAddr, source: String }

fn load_peers(path:&std::path::Path)->Vec<PeerCandidate>{
    std::fs::read_to_string(path).ok().map(|s|s.lines().filter_map(|l|l.parse::<SocketAddr>().ok()).map(|addr|PeerCandidate{addr,source:"peers.dat".into()}).collect()).unwrap_or_default()
}
fn save_peer(path:&std::path::Path,addr:SocketAddr){
    let mut v=load_peers(path); if !v.iter().any(|x|x.addr==addr){v.push(PeerCandidate{addr,source:"peers.dat".into()});}
    v.truncate(512); let body=v.iter().map(|x|x.addr.to_string()).collect::<Vec<_>>().join("\n"); let _=std::fs::write(path,body);
}

fn peer_session(candidate:PeerCandidate,state:SharedState,peer_file:std::path::PathBuf)->bool{
    let addr=candidate.addr; let source=candidate.source.clone();
    {let mut st=state.write().unwrap();st.connection_source=source.clone();st.connection_endpoint=addr.to_string();st.connection_detail="opening TCP connection".into();st.message=format!("connecting to {addr} via {source}");}
    let mut s=match connect_with_timeout(addr,Duration::from_secs(10)){Ok(s)=>s,Err(e)=>{let mut st=state.write().unwrap();st.connection_detail=format!("TCP connection failed: {e}");st.message=format!("{source} failed for {addr}: {e}");return false;}};
    let local="0.0.0.0:0".parse().unwrap(); let nonce=unix_time() as u64 ^ std::process::id() as u64 ^ addr.port() as u64;
    if let Err(e)=send(&mut s,"version",&version_payload(ycash_network::runtime::NODE_NETWORK,addr,local,nonce,"/YcashAndroid:0.18.0/")){let mut st=state.write().unwrap();st.message=format!("version send failed: {e}");return false;}
    let mut got_v=false; let mut got_a=false;
    for _ in 0..24 {
        match read_message(&mut s){
            Ok((cmd,p)) if cmd=="version"=>{got_v=true;let h=advertised_height(&p);let mut st=state.write().unwrap();st.peers=st.peers.saturating_add(1);st.target_height=h;st.connection_source=source.clone();st.connection_endpoint=addr.to_string();st.connection_detail=format!("Ycash v{:?} received; peer height {:?}",PROTOCOL_VERSION,h);st.message=format!("handshake: {addr} via {source}");let _=send(&mut s,"verack",&[]);let _=send(&mut s,"getaddr",&[]);}
            Ok((cmd,p)) if cmd=="verack"=>{got_a=true;let mut st=state.write().unwrap();st.connection_detail="Ycash version + verack handshake complete".into();st.message=format!("P2P handshake complete: {addr} via {source}");}
            Ok((cmd,p)) if cmd=="addr"=>{if let Ok(addrs)=parse_addr_message(&p,1000){for a in addrs{save_peer(&peer_file,a)}}}
            Ok((cmd,p)) if cmd=="ping"=>{let _=send(&mut s,"pong",&p);}
            Ok((_,_))=>{}
            Err(e)=>{let mut st=state.write().unwrap();st.connection_detail=format!("P2P session failed: {e}");st.message=format!("{source} {addr} disconnected: {e}");break;}
        }
        if got_v&&got_a{break}
    }
    if !(got_v&&got_a){let mut st=state.write().unwrap();st.peers=st.peers.saturating_sub(1);st.connection_detail="handshake incomplete".into();return false;}
    save_peer(&peer_file,addr);
    let _=s.set_read_timeout(Some(Duration::from_secs(20)));
    loop{match read_message(&mut s){Ok((cmd,p)) if cmd=="ping"=>{if send(&mut s,"pong",&p).is_err(){break}},Ok((cmd,p)) if cmd=="addr"=>{if let Ok(addrs)=parse_addr_message(&p,1000){for a in addrs{save_peer(&peer_file,a)}}},Ok(_)=>{},Err(_)=>break}}
    let mut st=state.write().unwrap();st.peers=st.peers.saturating_sub(1);st.connection_detail=format!("Peer {addr} disconnected; peer database retained");st.message=format!("peer {addr} disconnected; rediscovering");false
}

fn peer_candidates(peer_file:&std::path::Path)->Vec<PeerCandidate>{
    const FIXED:&[(&str,&str)]=&[("Fixed Seed #1","3.130.144.65:8833"),("Fixed Seed #2","13.126.58.237:8833")];
    let mut out=Vec::new();
    if let Ok(v)=std::env::var("YCASH_PEER"){for x in v.split([',',';']).map(str::trim).filter(|x|!x.is_empty()){if let Ok(a)=x.to_socket_addrs(){for addr in a{out.push(PeerCandidate{addr,source:"Manual Peer".into()})}}}}
    for p in load_peers(peer_file){out.push(p)}
    if let Ok(a)="seed.ycash.xyz:8833".to_socket_addrs(){for addr in a{out.push(PeerCandidate{addr,source:"DNS Seed (seed.ycash.xyz)".into()})}}
    for (label,s) in FIXED{if let Ok(mut a)=s.to_socket_addrs(){if let Some(addr)=a.next(){out.push(PeerCandidate{addr,source:(*label).into()})}}}
    let mut u=Vec::new();for c in out{if !u.iter().any(|x:&PeerCandidate|x.addr==c.addr){u.push(c)}}u
}

fn peer_supervisor(state:SharedState){
    let base=std::env::var("YCASH_DATA_DIR").map(std::path::PathBuf::from).unwrap_or_else(|_|std::env::temp_dir().join("ycash-android-node"));let _=std::fs::create_dir_all(&base);let peer_file=base.join("peers.dat");
    loop{
        let candidates=peer_candidates(&peer_file);if candidates.is_empty(){let mut st=state.write().unwrap();st.peers=0;st.connection_source="None".into();st.connection_endpoint="—".into();st.connection_detail="No Ycash peer addresses available".into();st.message="peer discovery retry in 10 seconds".into();drop(st);thread::sleep(Duration::from_secs(10));continue;}
        let max=8usize;let mut handles=Vec::new();
        for c in candidates.into_iter().take(max){let st=state.clone();let pf=peer_file.clone();handles.push(thread::spawn(move||peer_session(c,st,pf)));}
        for h in handles{let _=h.join();}
        thread::sleep(Duration::from_secs(3));
    }
}

fn main(){let state=Arc::new(RwLock::new(LiveNodeState{running:true,..Default::default()}));if let Err(e)=start_api(state.clone()){eprintln!("API failed: {e}");return}println!("Ycash Android Rust Full P2P Node v0.18.0");println!("Live UI API: http://127.0.0.1:8834/status");let st=state.clone();thread::spawn(move||peer_supervisor(st));loop{thread::park()}}
