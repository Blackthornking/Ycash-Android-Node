# Development Status

Current project line: v0.12 — real Android process + initial live P2P handshake.

Implemented and wired:
- Rust Android node is a workspace member and builds as its own binary.
- Android foreground service launches the bundled ARM64 node process.
- Node exposes localhost status telemetry.
- Node resolves `YCASH_PEER` or defaults to `seed.ycash.xyz:8833`.
- Node sends `version`, receives `version`, sends/receives `verack`, and answers `ping` with `pong`.
- Peer advertised start height is surfaced as target/header telemetry.

Not yet complete:
- Header locator construction and validated header synchronization.
- Block download, consensus validation and persistent main-chain commit.
- Full peer discovery/peer manager and transaction relay.

These are deliberately not reported as complete until tested against Ycash mainnet and a reference node.
