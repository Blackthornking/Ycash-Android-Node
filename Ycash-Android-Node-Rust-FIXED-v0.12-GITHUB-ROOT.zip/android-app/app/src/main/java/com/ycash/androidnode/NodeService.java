package com.ycash.androidnode;

import android.app.*;
import android.content.*;
import android.os.*;
import java.io.*;

public class NodeService extends Service {
    static final String START="START", STOP="STOP";
    static Process process;
    public void onCreate(){super.onCreate();}
    public int onStartCommand(Intent i,int flags,int id){
        if(i!=null && STOP.equals(i.getAction())){ stopNode(); stopForeground(STOP_FOREGROUND_REMOVE); stopSelf(); return START_NOT_STICKY; }
        if(Build.VERSION.SDK_INT>=26) startForeground(7, notification());
        if(process==null || !process.isAlive()) startNode();
        return START_STICKY;
    }
    void startNode(){ new Thread(()->{
        try {
            File bin=new File(getFilesDir(),"ycash-android-node");
            if(!bin.exists()){ try(InputStream in=getAssets().open("ycash-android-node"); OutputStream out=new FileOutputStream(bin)){byte[] b=new byte[65536];int n;while((n=in.read(b))!=-1)out.write(b,0,n);} }
            bin.setExecutable(true,false);
            ProcessBuilder pb=new ProcessBuilder(bin.getAbsolutePath()); pb.directory(getFilesDir());
            pb.environment().put("YCASH_NODE_DB",new File(getFilesDir(),"ycash-node.sqlite").getAbsolutePath());
            pb.redirectErrorStream(true); pb.redirectOutput(new File(getFilesDir(),"node.log")); process=pb.start(); process.waitFor();
        } catch(Exception e) { try(FileWriter w=new FileWriter(new File(getFilesDir(),"node.log"),true)){w.write("START ERROR: "+e+"\n");}catch(Exception ignored){} }
    }).start(); }
    void stopNode(){ if(process!=null && process.isAlive()) process.destroy(); process=null; }
    Notification notification(){ String ch="ycash-node"; if(Build.VERSION.SDK_INT>=26){NotificationChannel c=new NotificationChannel(ch,"Ycash Node",NotificationManager.IMPORTANCE_LOW);getSystemService(NotificationManager.class).createNotificationChannel(c);} return new Notification.Builder(this,ch).setContentTitle("Ycash Android Node").setContentText("Ycash node is running").setSmallIcon(android.R.drawable.stat_sys_download_done).setOngoing(true).build(); }
    public IBinder onBind(Intent i){return null;} public void onDestroy(){stopNode();super.onDestroy();}
}
