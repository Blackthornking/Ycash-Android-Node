# Ycash Android Node — Rust Full v0.3

This stage moves the project from a placeholder consensus boundary to an explicit, strict Ycash 4.5.0
consensus oracle integration and differential-testing plan.

## Security rule

The Rust node does not invent consensus rules. Until the Ycash 4.5.0 native consensus core is linked and
historically differential-tested, consensus validation remains fail-closed.

## Why this stage matters

Ycash 4.5.0 fixed an insufficiently checked block vulnerability involving the `fChecked` validation cache.
The strict bridge therefore uses `ProofVerifier::Strict()` and `CheckBlock` with proof, merkle, and transaction
checks enabled.

## Modern architecture

The node follows the useful separation demonstrated by modern Rust nodes: chain types, consensus, state,
networking and orchestration are independent layers. This makes Android resource management and testing easier.

## Next release gate

- Link the bridge against the pinned Ycash 4.5.0 native core.
- Compile for aarch64-linux-android.
- Run the complete differential suite.
- Replay historical Ycash blocks.
- Synchronize against Ycash mainnet.
- Only then enable the Rust node as a validating network peer.


## v0.5
Chain-state engine added: cumulative-work selection, fork discovery, rollback paths, and undo records.

## v0.6
Synchronization engine primitives: bounded block scheduling, header tracking, work selection, and request lifecycle.

## v0.7
Live Ycash mainnet wire/connectivity foundation with bounded message framing and peer scoring.

## v0.8
Live TCP transport runtime, message receive/checksum path, version/getheaders serialization, and read-only connectivity probe.

## v0.8 UI
Basic Android test UI added with node status, peer/height/sync placeholders, start/stop controls, and a real TCP connectivity test for Ycash mainnet port 8833.

## v0.9 Real UI telemetry
Android UI now polls a localhost `/status` endpoint for node status, peer count, height, sync state, and message. Rust defines the JSON status contract.

## v0.10
Node-owned localhost telemetry endpoint wired to Android UI.

## v0.11
Live shared node-state telemetry wired to the Android UI, including peer count, committed height, headers height, and derived sync percentage.

## Development roadmap
See `REMAINING_STAGES.md` for the remaining implementation stages and `DEVELOPMENT_STATUS.md` for current status.
