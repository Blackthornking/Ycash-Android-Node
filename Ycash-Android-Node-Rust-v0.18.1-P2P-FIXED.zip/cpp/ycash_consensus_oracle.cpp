#include "ycash_consensus_oracle.h"
#include <chainparams.h>
#include <main.h>
#include <proof_verifier.h>
#include <serialize.h>
#include <streams.h>
#include <primitives/block.h>
#include <primitives/transaction.h>
#include <utilstrencodings.h>
#include <cstring>
#include <string>

static void set_reason(char* out, size_t n, const std::string& s) {
    if (!out || n == 0) return;
    size_t m = s.size() < n - 1 ? s.size() : n - 1;
    std::memcpy(out, s.data(), m);
    out[m] = 0;
}

extern "C" int ycash_check_block_mainnet(const uint8_t* data, size_t len,
                                          int check_pow, int check_merkle,
                                          int check_transactions,
                                          char* reason, size_t reason_len) {
    try {
        SelectParams(CBaseChainParams::MAIN);
        CDataStream ss(data, data + len, SER_NETWORK, PROTOCOL_VERSION);
        CBlock block;
        ss >> block;
        if (!ss.empty()) {
            set_reason(reason, reason_len, "trailing bytes after block");
            return 0;
        }
        CValidationState state;
        ProofVerifier verifier = ProofVerifier::Strict();
        bool ok = CheckBlock(block, state, Params(), verifier,
                             check_pow != 0, check_merkle != 0,
                             check_transactions != 0);
        if (!ok) {
            set_reason(reason, reason_len, state.GetRejectReason());
            return 0;
        }
        set_reason(reason, reason_len, "ok");
        return 1;
    } catch (const std::exception& e) {
        set_reason(reason, reason_len, e.what());
        return -1;
    } catch (...) {
        set_reason(reason, reason_len, "unknown bridge exception");
        return -1;
    }
}

extern "C" int ycash_check_tx_mainnet(const uint8_t* data, size_t len,
                                       char* reason, size_t reason_len) {
    try {
        SelectParams(CBaseChainParams::MAIN);
        CDataStream ss(data, data + len, SER_NETWORK, PROTOCOL_VERSION);
        CTransaction tx;
        ss >> tx;
        if (!ss.empty()) {
            set_reason(reason, reason_len, "trailing bytes after transaction");
            return 0;
        }
        CValidationState state;
        bool ok = CheckTransaction(tx, state, ProofVerifier::Strict());
        if (!ok) {
            set_reason(reason, reason_len, state.GetRejectReason());
            return 0;
        }
        set_reason(reason, reason_len, "ok");
        return 1;
    } catch (const std::exception& e) {
        set_reason(reason, reason_len, e.what());
        return -1;
    } catch (...) {
        set_reason(reason, reason_len, "unknown bridge exception");
        return -1;
    }
}
