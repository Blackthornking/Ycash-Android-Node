#!/usr/bin/env bash
set -euo pipefail

: "${YCASH_SRC:?Set YCASH_SRC to the ycash-4.5.0 source tree}"
: "${ANDROID_NDK_HOME:?Set ANDROID_NDK_HOME}"
: "${ANDROID_ABI:=arm64-v8a}"
: "${API:=35}"

case "$ANDROID_ABI" in
  arm64-v8a) TARGET=aarch64-linux-android;;
  *) echo "Unsupported ABI: $ANDROID_ABI" >&2; exit 2;;
esac

if [[ ! -f "$YCASH_SRC/src/main.cpp" || ! -f "$YCASH_SRC/src/chainparams.cpp" ]]; then
  echo "YCASH_SRC does not look like ycash-4.5.0" >&2
  exit 2
fi

# This script is intentionally a build orchestrator rather than a fake one-command build:
# ycash-4.5.0 has native dependencies and generated build files that must be built with the
# same NDK/sysroot. The CI job should configure those dependencies first, then compile the
# consensus bridge and link it into the Rust node.

export CC="$ANDROID_NDK_HOME/toolchains/llvm/prebuilt/linux-x86_64/bin/${TARGET}${API}-clang"
export CXX="$ANDROID_NDK_HOME/toolchains/llvm/prebuilt/linux-x86_64/bin/${TARGET}${API}-clang++"
export AR="$ANDROID_NDK_HOME/toolchains/llvm/prebuilt/linux-x86_64/bin/llvm-ar"

printf 'Ycash source: %s\nTarget: %s\nAPI: %s\n' "$YCASH_SRC" "$TARGET" "$API"
printf '%s\n' 'Next: configure/build the pinned Ycash 4.5.0 native dependency set, then link cpp/ycash_consensus_oracle.cpp.'
