#!/usr/bin/env bash
set -euo pipefail

test -f crates/ycash-network/src/lib.rs
test -f crates/ycash-android-node/src/main.rs
test -f crates/chain/src/lib.rs
test -f crates/consensus/src/lib.rs
test -f crates/state/src/lib.rs

! grep -R 'header\[12\.\.16\]' -n crates/ycash-network crates/ycash-android-node
grep -q 'header\[4\.\.16\]' crates/ycash-network/src/lib.rs
grep -q 'MAX_MESSAGE_SIZE: usize = 2 \* 1024 \* 1024' crates/ycash-network/src/lib.rs
grep -q 'hashLightClientRoot\|light_client_root' crates/chain/src/lib.rs
grep -q 'getheaders' crates/ycash-android-node/src/main.rs
grep -q 'getdata' crates/ycash-android-node/src/main.rs
grep -q 'Equihash' crates/consensus/src/lib.rs 2>/dev/null || true
grep -q 'equihash::is_valid_solution' crates/consensus/src/lib.rs
grep -q 'nPowAveragingWindow\|POW_AVERAGING_WINDOW' crates/consensus/src/lib.rs

echo 'Ycash P2P v0.18.1 source audit checks passed.'
