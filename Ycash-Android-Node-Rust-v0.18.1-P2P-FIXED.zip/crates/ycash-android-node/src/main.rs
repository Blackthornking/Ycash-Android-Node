use sha2::{Digest, Sha256};
use std::io::{Read, Write};
use std::net::{SocketAddr, TcpListener, TcpStream, ToSocketAddrs};
use std::path::{Path, PathBuf};
use std::sync::{atomic::{AtomicBool, Ordering}, Arc, RwLock};
use std::thread;
use std::time::{Duration, Instant};
use ycash_chain::{genesis_hash_internal, read_block_at_height, read_header_at, BlockHeader, YCASH_FORK_HEIGHT, MAX_HEADERS_RESULTS};
use ycash_consensus::{validate_header, validate_for_commit, Context, block_proof, add_work, minimum_chain_work};
use ycash_network::runtime::{connect_with_timeout, getdata_payload, getheaders_payload, parse_addr_message, unix_time, version_payload};
use ycash_network::{decode_header, encode_message, Hash256, PROTOCOL_VERSION};
use ycash_state::State;

mod runtime;
use runtime::{LiveNodeState, SharedState};

struct DoubleSha;
impl Hash256 for DoubleSha { fn hash256(data: &[u8]) -> [u8;32] { let a=Sha256::digest(data); let b=Sha256::digest(a); let mut out=[0u8;32]; out.copy_from_slice(&b); out } }

fn esc(s:&str)->String{s.replace('\\',"\\\\").replace('"',"\\\"")}
fn json(s:&LiveNodeState)->String{format!(r#"{{"status":"{}","peers":{},"height":{},"headers_height":{},"sync":"{}","connection_source":"{}","connection_endpoint":"{}","connection_detail":"{}","message":"{}"}}"#,if s.running{"running"}else{"stopped"},s.peers,s.local_height,s.headers_height,esc(&s.sync_text()),esc(&s.connection_source),esc(&s.connection_endpoint),esc(&s.connection_detail),esc(&s.message))}
fn serve(mut stream:TcpStream,state:SharedState){let mut b=[0u8;2048];let _=stream.read(&mut b);let req=String::from_utf8_lossy(&b);let(code,body)=if req.lines().next().unwrap_or("").starts_with("GET /status "){("200 OK",json(&state.read().unwrap()))}else{("404 Not Found",r#"{"error":"not found"}"#.into())};let r=format!("HTTP/1.1 {code}\r\nContent-Type: application/json\r\nCache-Control: no-store\r\nContent-Length: {}\r\nConnection: close\r\n\r\n{}",body.len(),body);let _=stream.write_all(r.as_bytes());}
fn start_api(state:SharedState)->std::io::Result<()> {let listener=TcpListener::bind(("127.0.0.1",8834))?;thread::spawn(move||for s in listener.incoming(){if let Ok(s)=s{let st=state.clone();thread::spawn(move||serve(s,st));}});Ok(())}
fn read_message(stream:&mut TcpStream)->std::io::Result<(String,Vec<u8>)>{let mut h=[0u8;24];stream.read_exact(&mut h)?;let(cmd,len,checksum)=decode_header::<DoubleSha>(&h)?;if len as usize>2*1024*1024{return Err(std::io::Error::new(std::io::ErrorKind::InvalidData,"message exceeds Ycash 2 MiB limit"))}let mut p=vec![0u8;len as usize];stream.read_exact(&mut p)?;if DoubleSha::hash256(&p)[..4]!=checksum{return Err(std::io::Error::new(std::io::ErrorKind::InvalidData,"checksum mismatch"))}Ok((cmd,p))}
fn send(stream:&mut TcpStream,cmd:&str,payload:&[u8])->std::io::Result<()>{stream.write_all(&encode_message::<DoubleSha>(cmd,payload)?)}

#[derive(Clone,Debug)]struct PeerCandidate{addr:SocketAddr,source:String}
#[derive(Clone,Debug)]struct PeerRecord{addr:SocketAddr,last_seen:u64,attempts:u32,tried:bool}
fn load_peer_records(path:&Path)->Vec<PeerRecord>{std::fs::read_to_string(path).ok().map(|s|s.lines().filter_map(|l|{let f:Vec<_>=l.split('\t').collect();if f.len()>=4{Some(PeerRecord{addr:f[0].parse().ok()?,last_seen:f[1].parse().unwrap_or(0),attempts:f[2].parse().unwrap_or(0),tried:f[3]=="1"})}else{Some(PeerRecord{addr:l.parse().ok()?,last_seen:0,attempts:0,tried:false})}}).collect()).unwrap_or_default()}
fn save_peer_records(path:&Path,records:&[PeerRecord]){let body=records.iter().take(512).map(|r|format!("{}\t{}\t{}\t{}",r.addr,r.last_seen,r.attempts,if r.tried{"1"}else{"0"})).collect::<Vec<_>>().join("\n");let _=std::fs::write(path,body);}
fn save_peer(path:&Path,addr:SocketAddr){let mut v=load_peer_records(path);if let Some(r)=v.iter_mut().find(|r|r.addr==addr){r.last_seen=unix_time() as u64;r.tried=true;}else{v.push(PeerRecord{addr,last_seen:unix_time() as u64,attempts:0,tried:true});}v.sort_by_key(|r|std::cmp::Reverse((r.tried,r.last_seen)));save_peer_records(path,&v)}
fn ban_peer(base:&Path,addr:SocketAddr){let p=base.join("banlist.dat");let mut v=std::fs::read_to_string(&p).unwrap_or_default();if !v.lines().any(|x|x.trim()==addr.to_string()){v.push_str(&format!("{}\t{}\n",addr,unix_time()+24*60*60));let _=std::fs::write(p,v);}}
fn is_banned(base:&Path,addr:SocketAddr)->bool{let p=base.join("banlist.dat");let now=unix_time();std::fs::read_to_string(p).ok().map(|s|s.lines().any(|l|{let f:Vec<_>=l.split('\t').collect();f.len()>=2&&f[0]==addr.to_string()&&f[1].parse::<i64>().unwrap_or(0)>now})).unwrap_or(false)}

fn mark_peer_attempt(path:&Path,addr:SocketAddr){let mut v=load_peer_records(path);if let Some(r)=v.iter_mut().find(|r|r.addr==addr){r.attempts=r.attempts.saturating_add(1);}else{v.push(PeerRecord{addr,last_seen:0,attempts:1,tried:false});}save_peer_records(path,&v)}

fn parse_version_height(version:&[u8])->Option<u64>{let mut i=4+8+8+26+26+8;let b=*version.get(i)?;let n=match b{0..=252=>{i+=1;b as usize},253=>{let x=version.get(i+1..i+3)?;i+=3;u16::from_le_bytes([x[0],x[1]]) as usize},254=>{let x=version.get(i+1..i+5)?;i+=5;u32::from_le_bytes(x.try_into().ok()?) as usize},255=>{let x=version.get(i+1..i+9)?;i+=9;u64::from_le_bytes(x.try_into().ok()?) as usize}};i=i.checked_add(n)?;if version.len()<i+4{return None}Some(i32::from_le_bytes(version[i..i+4].try_into().ok()?).max(0) as u64)}

fn header_from_raw(raw:&[u8],height:u64)->std::io::Result<BlockHeader>{let mut c=std::io::Cursor::new(raw);read_header_at(&mut c,height).map_err(|e|std::io::Error::new(std::io::ErrorKind::InvalidData,e.to_string()))}
fn mtp(state:&State,height:u64)->u32{let start=height.saturating_sub(11);let mut times=Vec::new();for h in start..height{if let Ok(Some(raw))=state.header_by_height(h){if let Ok(x)=header_from_raw(&raw,h){times.push(x.time);}}}if times.is_empty(){0}else{times.sort_unstable();times[times.len()/2]}}

fn load_header_history(state:&State, next_height:u64)->std::io::Result<(u64,Vec<BlockHeader>)>{
    if next_height<=1{return Ok((1,Vec::new()));}
    let end=next_height-1;
    let start=end.saturating_sub(27).max(1);
    let mut out=Vec::new();
    for h in start..=end{
        let raw=state.header_by_height(h).map_err(|e|ioe(&e.to_string()))?.ok_or_else(||ioe(&format!("missing header {h}")))?;
        out.push(header_from_raw(&raw,h)?);
    }
    Ok((start,out))
}

fn parse_headers(payload:&[u8],start_height:u64)->std::io::Result<Vec<(u64,BlockHeader,Vec<u8>)>>{
    let mut i=0usize;let count=ycash_network::runtime::read_compact_size(payload,&mut i).map_err(|e|e)? as usize;if count>MAX_HEADERS_RESULTS{return Err(std::io::Error::new(std::io::ErrorKind::InvalidData,"too many headers"))}let mut out=Vec::with_capacity(count);for n in 0..count{let height=start_height+n as u64;let begin=i;let slice=&payload[i..];let mut c=std::io::Cursor::new(slice);let h=read_header_at(&mut c,height).map_err(|e|std::io::Error::new(std::io::ErrorKind::InvalidData,e.to_string()))?;i+=c.position() as usize;let _tx_count=ycash_network::runtime::read_compact_size(payload,&mut i).map_err(|e|e)?;out.push((height,h,payload[begin..i].to_vec()));}Ok(out)}

fn sync_headers(stream:&mut TcpStream,state:Arc<State>,live:&SharedState,source:&str,endpoint:&str)->std::io::Result<u64>{
    let mut next=state.header_height().map_err(|e| ioe(&e.to_string()))?.unwrap_or(0)+1;
    loop{
        let locator=state.locator_hashes().map_err(|e| ioe(&e.to_string()))?;let stop=[0u8;32];send(stream,"getheaders",&getheaders_payload(&locator,&stop))?;
        let (cmd,payload)=read_message(stream)?;if cmd!="headers"{if cmd=="ping"{send(stream,"pong",&payload)?;continue}if cmd=="reject"{return Err(std::io::Error::new(std::io::ErrorKind::ConnectionAborted,"peer rejected getheaders"))}continue;}
        let batch=parse_headers(&payload,next)?;if batch.is_empty(){break;}
        for (height,h,raw) in batch.iter(){
            let prev_hash=if *height==1{genesis_hash_internal()}else{state.header_hash_by_height(height-1).map_err(|e| ioe(&e.to_string()))?.ok_or_else(||ioe("missing previous header"))?.try_into().unwrap()};
            if h.prev!=prev_hash{return Err(ioe("header chain discontinuity"));}
            let mtp_time=mtp(&state,*height);if *height>1{let prev_raw=state.header_by_height(height-1).map_err(|e| ioe(&e.to_string()))?.ok_or_else(||ioe("missing previous header"))?;let prev=header_from_raw(&prev_raw,height-1)?;let (hist_start,hist)=load_header_history(&state,*height)?;validate_header(h,*height,&prev,mtp_time,hist_start,&hist).map_err(|e|ioe(&format!("header validation failed at {height}: {e:?}")))?;}else{ycash_consensus::check_pow(h,*height).map_err(|e|ioe(&format!("genesis successor PoW invalid: {e:?}")))?;}
            let hash=h.hash();let proof=block_proof(h.bits).map_err(|e|ioe(&format!("work calculation failed: {e:?}")))?;let prev_work=if *height<=1{[0u8;32]}else{let w=state.header_work_by_height(height-1).map_err(|e|ioe(&e.to_string()))?.ok_or_else(||ioe("missing previous chain work"))?;w.try_into().map_err(|_|ioe("invalid previous chain work"))?};let chain_work=add_work(&prev_work,&proof);state.put_header(*height,&hash,&h.prev,h.time,h.bits,&chain_work,&h.serialize()).map_err(|e| ioe(&e.to_string()))?;
            let mut ls=live.write().unwrap();ls.headers_height=*height;ls.connection_source=source.into();ls.connection_endpoint=endpoint.into();ls.connection_detail=format!("validated Ycash header {} (Equihash {})",height,if *height>=YCASH_FORK_HEIGHT{"192,7"}else{"200,9"});ls.message=format!("header sync: height {}",height);
        }
        next+=batch.len() as u64;if batch.len()<MAX_HEADERS_RESULTS{break;}
    }
    let tip=next.saturating_sub(1);if let Some(w)=state.header_work_by_height(tip).map_err(|e|ioe(&e.to_string()))?{if w.len()==32{let mut x=[0u8;32];x.copy_from_slice(&w);if x.iter().cmp(minimum_chain_work().iter()).is_lt(){let mut ls=live.write().unwrap();ls.message=format!("header tip {tip} below Ycash minimum chain work");}}}Ok(tip)
}

fn download_blocks(stream:&mut TcpStream,state:Arc<State>,live:&SharedState,target:u64)->std::io::Result<()> {
    let mut h=state.tip_height().map_err(|e|ioe(&e.to_string()))?.unwrap_or(0)+1;
    while h<=target {
        let end=(h+15).min(target);
        let mut requests=Vec::new();
        for x in h..=end { if let Some(raw)=state.header_by_height(x).map_err(|e|ioe(&e.to_string()))? { requests.push((x,header_from_raw(&raw,x)?.hash())); } }
        if requests.is_empty(){break;}
        let hashes:Vec<[u8;32]>=requests.iter().map(|(_,x)|*x).collect();
        send(stream,"getdata",&getdata_payload(&hashes))?;
        let mut completed=0usize;
        let mut done=std::collections::HashSet::<u64>::new();
        while completed<requests.len(){
            let(cmd,payload)=read_message(stream)?;
            match cmd.as_str(){
                "block"=>{
                    let mut matched=None;
                    for (height,expected) in &requests{
                        if !done.contains(height){
                            let candidate=read_block_at_height(&payload,*height).map_err(|e|ioe(&e.to_string()))?;
                            if candidate.header.hash()==*expected{matched=Some((*height,candidate));break;}
                        }
                    }
                    let (height,block)=matched.ok_or_else(||ioe("received block is not one of the requested headers"))?;
                    let expected=requests.iter().find(|(x,_)|*x==height).map(|(_,h)|*h).unwrap();
                    let prev=if height==1{None}else{state.header_by_height(height-1).map_err(|e|ioe(&e.to_string()))?.map(|r|header_from_raw(&r,height-1)).transpose()?};
                    let prev_height=height.saturating_sub(1);
                    let mtp_time=mtp(&state,height);
                    let ctx=Context{height,prev_height,median_time_past:mtp_time};
                    if let Some(prev_header)=prev.as_ref(){if block.header.prev!=prev_header.hash(){return Err(ioe("block previous hash does not match stored header"));}}else if block.header.prev!=genesis_hash_internal(){return Err(ioe("first block does not point to Ycash genesis"));}
                    let _validated=validate_for_commit(&payload,ctx).map_err(|e|ioe(&format!("block validation failed at {height}: {e:?}")))?;
                    let work=state.header_work_by_height(height).map_err(|e|ioe(&e.to_string()))?.ok_or_else(||ioe("missing header chain work"))?;
                    state.put_block(height,&expected,&block.header.prev,&work,&payload).map_err(|e|ioe(&e.to_string()))?;
                    let tip=ycash_state::Tip{hash:expected.to_vec(),height,work:work.clone().try_into().map_err(|_|ioe("invalid chain work"))?};
                    state.set_tip(&tip).map_err(|e|ioe(&e.to_string()))?;
                    done.insert(height);completed+=1;
                    {let mut ls=live.write().unwrap();ls.local_height=height;ls.connection_detail=format!("validated block {}",height);ls.message=format!("block sync: height {}",height);}
                },
                "ping"=>{send(stream,"pong",&payload)?;},
                "reject"=>return Err(ioe("peer rejected block request")),
                _=>{}
            }
        }
        h=end+1;
    }
    Ok(())
}
fn inv_has_block(payload:&[u8])->bool{let mut i=0usize;let count=match ycash_network::runtime::read_compact_size(payload,&mut i){Ok(x)=>x as usize,Err(_)=>return false};if count>50000{return false}for _ in 0..count{if i+36>payload.len(){return false}let kind=u32::from_le_bytes(payload[i..i+4].try_into().unwrap());if kind==2{return true}i+=36;}false}

fn ioe(s:&str)->std::io::Error{std::io::Error::new(std::io::ErrorKind::InvalidData,s.to_string())}

fn peer_session(candidate:PeerCandidate,live:SharedState,peer_file:PathBuf,db:Arc<State>,sync_owner:Arc<AtomicBool>)->bool{
 let addr=candidate.addr;let source=candidate.source.clone();mark_peer_attempt(&peer_file,addr);{let mut st=live.write().unwrap();st.connection_source=source.clone();st.connection_endpoint=addr.to_string();st.connection_detail="opening TCP connection".into();st.message=format!("connecting to {addr} via {source}");}
 let mut s=match connect_with_timeout(addr,Duration::from_secs(10)){Ok(x)=>x,Err(e)=>{let mut st=live.write().unwrap();st.connection_detail=format!("TCP connection failed: {e}");return false;}};
 let start_height=db.header_height().ok().flatten().unwrap_or(0) as i32;let local="0.0.0.0:0".parse().unwrap();let nonce=unix_time() as u64 ^ std::process::id() as u64 ^ addr.port() as u64;
 if let Err(e)=send(&mut s,"version",&version_payload(ycash_network::runtime::NODE_NETWORK,addr,local,nonce,"/YcashAndroid:0.18.1/",start_height)){let mut st=live.write().unwrap();st.message=format!("version send failed: {e}");return false;}
 let mut got_v=false;let mut got_a=false;let mut peer_height=None;
 for _ in 0..64{match read_message(&mut s){Ok((cmd,p)) if cmd=="version"=>{if got_v{return false}if p.len()<4{return false}let peer_proto=i32::from_le_bytes(p[0..4].try_into().unwrap());if peer_proto<PROTOCOL_VERSION{let mut st=live.write().unwrap();st.message=format!("peer protocol {} is below required {}",peer_proto,PROTOCOL_VERSION);return false;}got_v=true;peer_height=parse_version_height(&p);let _=send(&mut s,"verack",&[]);let _=send(&mut s,"getaddr",&[]);let mut st=live.write().unwrap();st.target_height=peer_height;st.connection_detail=format!("Ycash protocol {} peer height {:?}",peer_proto,peer_height);},Ok((cmd,p)) if cmd=="verack"=>{got_a=true;let mut st=live.write().unwrap();st.connection_detail="Ycash version + verack handshake complete".into();},Ok((cmd,p)) if cmd=="addr"=>{if let Ok(addrs)=parse_addr_message(&p,1000){for a in addrs{save_peer(&peer_file,a)}}},Ok((cmd,p)) if cmd=="ping"=>{let _=send(&mut s,"pong",&p);},Ok(("reject",p))=>{let mut st=live.write().unwrap();st.message=format!("peer rejected message: {}",String::from_utf8_lossy(&p));},Ok(_)=>{},Err(e)=>{let mut st=live.write().unwrap();st.connection_detail=format!("handshake/session failed: {e}");return false;}}if got_v&&got_a{break}}
 if !(got_v&&got_a){let mut st=live.write().unwrap();st.connection_detail="handshake incomplete".into();return false;}
 save_peer(&peer_file,addr);{let mut st=live.write().unwrap();st.peers=st.peers.saturating_add(1);st.connection_source=source.clone();st.connection_endpoint=addr.to_string();}
 if sync_owner.compare_exchange(false,true,Ordering::AcqRel,Ordering::Acquire).is_ok(){
   let result=sync_headers(&mut s,db.clone(),&live,&source,&addr.to_string()).and_then(|tip|{let peer_tip=peer_height.unwrap_or(tip);download_blocks(&mut s,db.clone(),&live,peer_tip).map(|_|())});
   sync_owner.store(false,Ordering::Release);
   if let Err(e)=result{let detail=e.to_string();if detail.contains("validation")||detail.contains("Equihash")||detail.contains("nBits")||detail.contains("previous hash")||detail.contains("target")||detail.contains("chain discontinuity"){if let Some(base)=peer_file.parent(){ban_peer(base,addr);}}let mut st=live.write().unwrap();st.connection_detail=format!("sync stopped: {e}");st.message=format!("sync peer {addr} dropped: {e}");}
 }
 let _=s.set_read_timeout(Some(Duration::from_secs(5)));let _=s.set_write_timeout(Some(Duration::from_secs(30)));let mut last_ping_sent=Instant::now();let mut ping_deadline:Option<Instant>=None;let mut ping_nonce=unix_time() as u64 ^ addr.port() as u64;
 loop{match read_message(&mut s){Ok((cmd,p)) if cmd=="ping"=>{if send(&mut s,"pong",&p).is_err(){break}},Ok((cmd,p)) if cmd=="pong"=>{ping_deadline=None;let _=p;},Ok((cmd,p)) if cmd=="addr"=>{if let Ok(addrs)=parse_addr_message(&p,1000){for a in addrs{save_peer(&peer_file,a)}}},Ok((cmd,p)) if cmd=="inv"=>{if inv_has_block(&p)&&sync_owner.compare_exchange(false,true,Ordering::AcqRel,Ordering::Acquire).is_ok(){let result=sync_headers(&mut s,db.clone(),&live,&source,&addr.to_string()).and_then(|tip|download_blocks(&mut s,db.clone(),&live,peer_height.unwrap_or(tip)).map(|_|()));sync_owner.store(false,Ordering::Release);if let Err(e)=result{let mut st=live.write().unwrap();st.message=format!("live chain update failed: {e}");}}},Ok(("reject",p))=>{let mut st=live.write().unwrap();st.message=format!("peer reject: {}",String::from_utf8_lossy(&p));},Ok(_)=>{},Err(e) if e.kind()==std::io::ErrorKind::TimedOut=>{if let Some(deadline)=ping_deadline{if deadline.elapsed()>=Duration::from_secs(30){break}}if ping_deadline.is_none()&&last_ping_sent.elapsed()>=Duration::from_secs(120){ping_nonce=ping_nonce.wrapping_add(1);if send(&mut s,"ping",&ping_nonce.to_le_bytes()).is_err(){break}last_ping_sent=Instant::now();ping_deadline=Some(Instant::now());}},Err(_)=>break}}
 let mut st=live.write().unwrap();st.peers=st.peers.saturating_sub(1);st.connection_detail=format!("peer {addr} disconnected; peer database retained");false
}

fn peer_candidates(peer_file:&Path)->Vec<PeerCandidate>{const FIXED:&[(&str,&str)]=&[("Fixed Seed #1","3.130.144.65:8833"),("Fixed Seed #2","13.126.58.237:8833")];let mut out=Vec::new();if let Ok(v)=std::env::var("YCASH_PEER"){for x in v.split([',',';']).map(str::trim).filter(|x|!x.is_empty()){if let Ok(a)=x.to_socket_addrs(){for addr in a{out.push(PeerCandidate{addr,source:"Manual Peer".into()})}}}}for p in load_peer_records(peer_file){out.push(PeerCandidate{addr:p.addr,source:"peers.dat".into()})}if let Ok(a)="seed.ycash.xyz:8833".to_socket_addrs(){for addr in a{out.push(PeerCandidate{addr,source:"DNS Seed (seed.ycash.xyz)".into()})}}for(label,s)in FIXED{if let Ok(mut a)=s.to_socket_addrs(){if let Some(addr)=a.next(){out.push(PeerCandidate{addr,source:(*label).into()})}}}let base=peer_file.parent().unwrap_or(Path::new("."));let mut unique=Vec::new();for c in out{if is_banned(base,c.addr){continue}if !unique.iter().any(|x:&PeerCandidate|x.addr==c.addr){unique.push(c)}}let mut diverse=Vec::new();let mut groups=std::collections::HashSet::<String>::new();for c in &unique{let g=match c.addr.ip(){std::net::IpAddr::V4(v)=>format!("{}.{}.0.0",v.octets()[0],v.octets()[1]),std::net::IpAddr::V6(v)=>format!("{:x}:{:x}",u16::from_be_bytes([v.octets()[0],v.octets()[1]]),u16::from_be_bytes([v.octets()[2],v.octets()[3]]))};if groups.insert(g){diverse.push(c.clone())}}for c in unique{if !diverse.iter().any(|x:&PeerCandidate|x.addr==c.addr){diverse.push(c)}}diverse}
fn peer_supervisor(live:SharedState,db:Arc<State>){
    let base=std::env::var("YCASH_DATA_DIR").map(PathBuf::from).unwrap_or_else(|_|std::env::var("YCASH_NODE_DB").ok().and_then(|p|Path::new(&p).parent().map(Path::to_path_buf)).unwrap_or_else(||std::env::temp_dir().join("ycash-android-node")));
    let _=std::fs::create_dir_all(&base);let peer_file=base.join("peers.dat");let sync_owner=Arc::new(AtomicBool::new(false));
    let mut started:std::collections::HashSet<SocketAddr>=std::collections::HashSet::new();
    loop{
        let candidates=peer_candidates(&peer_file);
        for c in candidates.into_iter().filter(|c|!started.contains(&c.addr)).take(8-started.len().min(8)){
            started.insert(c.addr);let st=live.clone();let pf=peer_file.clone();let d=db.clone();let owner=sync_owner.clone();let initial=c.clone();
            thread::spawn(move||{let mut candidate=initial;loop{let _=peer_session(candidate.clone(),st.clone(),pf.clone(),d.clone(),owner.clone());thread::sleep(Duration::from_secs(3));let list=peer_candidates(&pf);if let Some(next)=list.into_iter().find(|x|x.addr!=candidate.addr){candidate=next;}}});
        }
        if started.len()>=8{thread::sleep(Duration::from_secs(15));}else{thread::sleep(Duration::from_secs(5));}
        if started.len()>8{break}
    }
}

fn main(){let state=Arc::new(RwLock::new(LiveNodeState{running:true,..Default::default()}));let db_path=std::env::var("YCASH_NODE_DB").map(PathBuf::from).unwrap_or_else(|_|std::env::var("YCASH_DATA_DIR").map(|p|PathBuf::from(p).join("ycash-node.sqlite")).unwrap_or_else(|_|PathBuf::from("ycash-node.sqlite")));if let Some(p)=db_path.parent(){let _=std::fs::create_dir_all(p);}let db=match State::open(&db_path){Ok(x)=>Arc::new(x),Err(e)=>{eprintln!("database open failed: {e}");return}};if let Ok(h)=db.header_height(){let mut s=state.write().unwrap();s.headers_height=h.unwrap_or(0);s.local_height=db.tip_height().ok().flatten().unwrap_or(0);}if let Err(e)=start_api(state.clone()){eprintln!("API failed: {e}");return}println!("Ycash Android Rust full P2P node v0.18.1");println!("Ycash mainnet magic 24e92764, port 8833, protocol 270013");let st=state.clone();let d=db.clone();thread::spawn(move||peer_supervisor(st,d));loop{thread::park()}}
