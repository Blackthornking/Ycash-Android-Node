use std::sync::{Arc, RwLock};

#[derive(Clone, Debug)]
pub struct LiveNodeState {
    pub running: bool,
    pub peers: u32,
    pub local_height: u64,
    pub target_height: Option<u64>,
    pub headers_height: u64,
    pub connection_source: String,
    pub connection_endpoint: String,
    pub connection_detail: String,
    pub message: String,
}
impl Default for LiveNodeState {
    fn default() -> Self {
        Self {
            running: false,
            peers: 0,
            local_height: 0,
            target_height: None,
            headers_height: 0,
            connection_source: "None".into(),
            connection_endpoint: "—".into(),
            connection_detail: "No active Ycash P2P connection".into(),
            message: "node ready".into(),
        }
    }
}
impl LiveNodeState {
    pub fn sync_text(&self) -> String {
        match self.target_height {
            Some(t) if t > self.local_height =>
                format!("{}%", ((self.local_height.saturating_mul(100))/t).min(100)),
            Some(_) => "100%".into(),
            None => "waiting for headers".into(),
        }
    }
}
pub type SharedState = Arc<RwLock<LiveNodeState>>;
