use num_bigint::BigUint;
use num_traits::Zero;
use ycash_chain::{Block, BlockHeader, YCASH_FORK_HEIGHT};

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum ConsensusError { Invalid(String), Contextual(String) }

#[derive(Debug, Clone, Copy)]
pub struct Context { pub height:u64, pub prev_height:u64, pub median_time_past:u32 }

pub const BLOSSOM_HEIGHT:u64=1_100_000;
pub const CANOPY_HEIGHT:u64=1_100_006;
pub const POW_AVERAGING_WINDOW:usize=17;
pub const POW_MEDIAN_BLOCK_SPAN:usize=11;
pub const POW_ADJUSTMENT_BLOCK_SPAN:usize=28;
pub const POW_DAMPING_FACTOR:i64=4;
pub const POW_MAX_ADJUST_UP:i64=16;
pub const POW_MAX_ADJUST_DOWN:i64=32;
pub const PRE_BLOSSOM_SPACING:i64=150;
pub const POST_BLOSSOM_SPACING:i64=75;
const POW_LIMIT_HEX:&str="0007ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff";

fn pow_limit()->BigUint{BigUint::parse_bytes(POW_LIMIT_HEX.as_bytes(),16).unwrap()}
fn compact_to_big(bits:u32)->Result<BigUint,ConsensusError>{let size=(bits>>24) as usize;let mant=bits&0x007f_ffff;if mant==0||(bits&0x0080_0000)!=0{return Err(ConsensusError::Invalid("negative/zero compact target".into()))}let mut v=BigUint::from(mant as u64);if size<=3{v >>= 8*(3-size)}else{v <<= 8*(size-3)}Ok(v)}
pub fn compact_to_target(bits:u32)->Result<[u8;32],ConsensusError>{let v=compact_to_big(bits)?;let b=v.to_bytes_be();if b.len()>32{return Err(ConsensusError::Invalid("compact target overflow".into()))}let mut out=[0u8;32];out[32-b.len()..].copy_from_slice(&b);Ok(out)}
fn big_to_compact(v:&BigUint)->u32{if v.is_zero(){return 0}let mut size=v.to_bytes_be().len() as u32;let mut compact:u32;if size<=3{compact=(v.clone()<<(8*(3-size))).to_u32_digits().first().copied().unwrap_or(0)}else{compact=(v>> (8*(size-3))).to_u32_digits().first().copied().unwrap_or(0)}if compact&0x0080_0000!=0{compact>>=8;size+=1}(size<<24)|(compact&0x007f_ffff)}
fn median_time(headers:&[BlockHeader],start_height:u64,end_height:u64)->u32{let first=end_height.saturating_sub((POW_MEDIAN_BLOCK_SPAN-1) as u64).max(start_height);let a=(first-start_height) as usize;let b=(end_height-start_height+1) as usize;if b>headers.len(){return headers.last().map(|h|h.time).unwrap_or(0)}let mut t:Vec<u32>=headers[a..b].iter().map(|h|h.time).collect();t.sort_unstable();t[t.len()/2]}
fn target_spacing(height:u64)->i64{if height>=BLOSSOM_HEIGHT{POST_BLOSSOM_SPACING}else{PRE_BLOSSOM_SPACING}}

pub fn expected_nbits(history:&[BlockHeader],history_start_height:u64,next_height:u64,candidate_time:u32)->Result<u32,ConsensusError>{
    let limit=pow_limit();
    if history.is_empty(){return Ok(big_to_compact(&limit));}
    let prev=&history[history.len()-1];
    // Ycash fork difficulty bootstrap, exactly as ycashd 4.5.0.
    if next_height>=YCASH_FORK_HEIGHT && next_height<YCASH_FORK_HEIGHT+POW_AVERAGING_WINDOW as u64{
        let spacing=target_spacing(next_height) as u32;
        let delta=candidate_time.saturating_sub(prev.time) as i64;
        let divisor=if delta>(spacing*12) as i64{64}else if delta>(spacing*6) as i64{128}else if delta>(spacing*2) as i64{256}else{0};
        if divisor!=0{return Ok(big_to_compact(&(limit/BigUint::from(divisor as u32))));}
    }
    if history.len()<POW_AVERAGING_WINDOW{return Ok(big_to_compact(&limit));}
    let start=history.len()-POW_AVERAGING_WINDOW;
    let mut total=BigUint::zero();
    for h in &history[start..]{total+=compact_to_big(h.bits)?;}
    let mean=&total / BigUint::from(POW_AVERAGING_WINDOW as u32);
    let spacing=target_spacing(next_height);
    let avg_span=spacing*POW_AVERAGING_WINDOW as i64;
    let min_span=avg_span*(100-POW_MAX_ADJUST_UP)/100;
    let max_span=avg_span*(100+POW_MAX_ADJUST_DOWN)/100;
    let last_height=history_start_height+history.len() as u64-1;
    let last_mtp=median_time(history,history_start_height,last_height) as i64;
    let first_height=last_height-(POW_AVERAGING_WINDOW as u64-1);
    let first_mtp=median_time(history,history_start_height,first_height) as i64;
    let actual=last_mtp-first_mtp;
    let mut bounded=avg_span+(actual-avg_span)/POW_DAMPING_FACTOR;
    if bounded<min_span{bounded=min_span}if bounded>max_span{bounded=max_span}
    let mut new_target=(mean/BigUint::from(avg_span as u64))*BigUint::from(bounded as u64);
    if new_target>limit{new_target=limit}
    Ok(big_to_compact(&new_target))
}

fn cmp_be(a:&[u8;32],b:&[u8;32])->std::cmp::Ordering{for i in 0..32{if a[i]!=b[i]{return a[i].cmp(&b[i])}}std::cmp::Ordering::Equal}
pub fn header_hash(header:&BlockHeader)->[u8;32]{header.hash()}
pub fn block_proof(bits:u32)->Result<[u8;32],ConsensusError>{let target=compact_to_big(bits)?;let mut denom=&target+BigUint::one();let numerator=(BigUint::one()<<256usize);let proof=numerator/denom;let b=proof.to_bytes_be();if b.len()>32{return Err(ConsensusError::Invalid("block proof overflow".into()))}let mut out=[0u8;32];out[32-b.len()..].copy_from_slice(&b);Ok(out)}
pub fn add_work(a:&[u8;32],b:&[u8;32])->[u8;32]{let mut out=[0u8;32];let mut carry=0u16;for i in (0..32).rev(){let x=a[i] as u16;let y=b[i] as u16;let z=x+y+carry;out[i]=(z&0xff) as u8;carry=z>>8;}out}
pub fn minimum_chain_work()->[u8;32]{let bytes=hex::decode("0000000000000000000000000000000000000000000000000152d8660f9d781c").unwrap();let mut out=[0u8;32];out.copy_from_slice(&bytes);out}
pub fn check_pow(header:&BlockHeader,height:u64)->Result<(),ConsensusError>{let(n,k,sol_len)=if height>=YCASH_FORK_HEIGHT{(192,7,400)}else{(200,9,1344)};if header.solution.len()!=sol_len{return Err(ConsensusError::Invalid(format!("wrong Equihash solution length at height {height}")))}let target=compact_to_target(header.bits)?;let limit=compact_to_target(big_to_compact(&pow_limit()))?;if cmp_be(&target,&limit)==std::cmp::Ordering::Greater{return Err(ConsensusError::Invalid("target exceeds Ycash PoW limit".into()))}equihash::is_valid_solution(n,k,&header.pow_input(),&header.nonce,&header.solution).map_err(|e|ConsensusError::Invalid(format!("invalid Equihash {n},{k}: {e:?}")))?;let raw=header.hash();let mut numeric=[0u8;32];for i in 0..32{numeric[i]=raw[31-i]}if cmp_be(&numeric,&target)==std::cmp::Ordering::Greater{return Err(ConsensusError::Invalid("header hash above target".into()))}Ok(())}

pub fn validate_header(header:&BlockHeader,height:u64,prev:&BlockHeader,mtp:u32,history_start_height:u64,history:&[BlockHeader])->Result<(),ConsensusError>{if header.prev!=prev.hash(){return Err(ConsensusError::Contextual("previous hash mismatch".into()))}if header.time<=mtp{return Err(ConsensusError::Contextual("timestamp is not greater than median-time-past".into()))}if header.time>mtp.saturating_add(5400){return Err(ConsensusError::Contextual("timestamp exceeds MTP + 90 minutes".into()))}let expected=expected_nbits(history,history_start_height,height,header.time)?;if header.bits!=expected{return Err(ConsensusError::Contextual(format!("unexpected nBits at height {height}: got {:08x}, expected {:08x}",header.bits,expected)))}check_pow(header,height)}

pub fn check_context(block:&Block,ctx:Context)->Result<(),ConsensusError>{if ctx.height!=ctx.prev_height+1{return Err(ConsensusError::Contextual("non-contiguous height".into()))}if block.header.time<=ctx.median_time_past{return Err(ConsensusError::Contextual("block time not greater than median-time-past".into()))}check_pow(&block.header,ctx.height)?;if block.txs.is_empty(){return Ok(())}if ycash_chain::merkle_root(&block.txs)!=block.header.merkle{return Err(ConsensusError::Invalid("transaction merkle root mismatch".into()))}Ok(())}
pub fn validate_for_commit(raw:&[u8],ctx:Context)->Result<Block,ConsensusError>{let block=ycash_chain::read_block_at_height(raw,ctx.height).map_err(|e|ConsensusError::Invalid(e.to_string()))?;check_context(&block,ctx)?;Ok(block)}

#[cfg(test)]
mod tests{use super::*;#[test]fn compact_roundtrip_limit(){let b=big_to_compact(&pow_limit());assert_eq!(b,0x1f07ffff);let _=compact_to_target(b).unwrap();}}
