use anyhow::Result;
use std::path::PathBuf;
use ycash_state::{State,Tip};

#[tokio::main]
async fn main()->Result<()>{
 tracing_subscriber::fmt::init();
 let db=std::env::var_os("YCASH_NODE_DB").map(PathBuf::from).unwrap_or_else(||PathBuf::from("ycash-node.sqlite"));
 let state=State::open(db)?;
 tracing::info!(tip=?state.tip_height()?,"Ycash Android Node state engine initialized");
 Ok(())
}
