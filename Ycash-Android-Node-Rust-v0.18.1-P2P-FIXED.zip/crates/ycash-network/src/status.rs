//! Local status API contract shared with the Android UI.
//! The Android UI polls GET /status on localhost:8834.
//! The production node must populate these values from live state.

#[derive(Clone, Debug)]
pub struct NodeStatus {
    pub status: String,
    pub peers: u32,
    pub height: u64,
    pub sync: String,
    pub message: String,
}

impl NodeStatus {
    pub fn to_json(&self) -> String {
        fn esc(s:&str)->String { s.replace('\\',"\\\\").replace('"',"\\\"") }
        format!(
            r#"{{"status":"{}","peers":{},"height":{},"sync":"{}","message":"{}"}}"#,
            esc(&self.status), self.peers, self.height, esc(&self.sync), esc(&self.message)
        )
    }
}
