use anyhow::{bail, Result};
use byteorder::{LittleEndian, ReadBytesExt};
use sha2::{Digest, Sha256};
use std::io::{Cursor, Read};

pub const MAINNET_MAGIC: [u8; 4] = [0x24, 0xe9, 0x27, 0x64];
pub const MAINNET_PORT: u16 = 8833;
pub const NETWORK: &str = "main";
pub const YCASH_FORK_HEIGHT: u64 = 570_000;
pub const MAX_HEADERS_RESULTS: usize = 160;
pub const MAX_BLOCK_SIZE: usize = 2 * 1024 * 1024;
pub const GENESIS_HASH_DISPLAY: &str = "00040fe8ec8471911baa1db1266ea15dd06b4a8a5c453883c000b031973dce08";

#[derive(Clone, Debug, PartialEq, Eq)]
pub struct BlockHeader {
    pub version: u32,
    pub prev: [u8; 32],
    pub merkle: [u8; 32],
    pub light_client_root: [u8; 32],
    pub time: u32,
    pub bits: u32,
    pub nonce: [u8; 32],
    pub solution: Vec<u8>,
}

impl BlockHeader {
    pub fn serialize(&self) -> Vec<u8> {
        let mut out = Vec::with_capacity(108 + 32 + 5 + self.solution.len());
        out.extend_from_slice(&self.version.to_le_bytes());
        out.extend_from_slice(&self.prev);
        out.extend_from_slice(&self.merkle);
        out.extend_from_slice(&self.light_client_root);
        out.extend_from_slice(&self.time.to_le_bytes());
        out.extend_from_slice(&self.bits.to_le_bytes());
        out.extend_from_slice(&self.nonce);
        write_compact_size(self.solution.len() as u64, &mut out);
        out.extend_from_slice(&self.solution);
        out
    }

    pub fn pow_input(&self) -> Vec<u8> {
        let mut out = Vec::with_capacity(108);
        out.extend_from_slice(&self.version.to_le_bytes());
        out.extend_from_slice(&self.prev);
        out.extend_from_slice(&self.merkle);
        out.extend_from_slice(&self.light_client_root);
        out.extend_from_slice(&self.time.to_le_bytes());
        out.extend_from_slice(&self.bits.to_le_bytes());
        out
    }

    pub fn hash(&self) -> [u8; 32] {
        let serialized = self.serialize();
        let a = Sha256::digest(&serialized);
        let b = Sha256::digest(a);
        let mut h = [0u8; 32];
        h.copy_from_slice(&b);
        h
    }
}

#[derive(Clone, Debug, PartialEq, Eq)]
pub struct Block {
    pub header: BlockHeader,
    pub txs: Vec<Vec<u8>>,
}

pub fn write_compact_size(n: u64, out: &mut Vec<u8>) {
    match n {
        0..=252 => out.push(n as u8),
        253..=65_535 => { out.push(253); out.extend_from_slice(&(n as u16).to_le_bytes()); }
        65_536..=0xffff_ffff => { out.push(254); out.extend_from_slice(&(n as u32).to_le_bytes()); }
        _ => { out.push(255); out.extend_from_slice(&n.to_le_bytes()); }
    }
}

pub fn read_compact_size(c: &mut Cursor<&[u8]>) -> Result<u64> {
    let n = c.read_u8()?;
    Ok(match n {
        0..=252 => n as u64,
        253 => c.read_u16::<LittleEndian>()? as u64,
        254 => c.read_u32::<LittleEndian>()? as u64,
        255 => c.read_u64::<LittleEndian>()?,
    })
}

pub fn read_bytes(c: &mut Cursor<&[u8]>, max: usize) -> Result<Vec<u8>> {
    let n = read_compact_size(c)? as usize;
    if n > max { bail!("field too large: {n}") }
    let mut v = vec![0; n];
    c.read_exact(&mut v)?;
    Ok(v)
}

pub fn expected_solution_len(height: u64) -> usize {
    if height >= YCASH_FORK_HEIGHT { 400 } else { 1344 }
}

pub fn read_header_at(c: &mut Cursor<&[u8]>, height: u64) -> Result<BlockHeader> {
    let version = c.read_u32::<LittleEndian>()?;
    let mut prev = [0; 32]; c.read_exact(&mut prev)?;
    let mut merkle = [0; 32]; c.read_exact(&mut merkle)?;
    let mut light_client_root = [0; 32]; c.read_exact(&mut light_client_root)?;
    let time = c.read_u32::<LittleEndian>()?;
    let bits = c.read_u32::<LittleEndian>()?;
    let mut nonce = [0; 32]; c.read_exact(&mut nonce)?;
    let solution = read_bytes(c, expected_solution_len(height))?;
    if solution.len() != expected_solution_len(height) {
        bail!("invalid Equihash solution length {} at height {}", solution.len(), height);
    }
    Ok(BlockHeader { version, prev, merkle, light_client_root, time, bits, nonce, solution })
}

fn tx_hash(tx:&[u8])->[u8;32]{let a=Sha256::digest(tx);let b=Sha256::digest(a);let mut o=[0u8;32];o.copy_from_slice(&b);o}
pub fn merkle_root(txs:&[Vec<u8>])->[u8;32]{if txs.is_empty(){return [0u8;32]}let mut layer:Vec<[u8;32]>=txs.iter().map(|t|tx_hash(t)).collect();while layer.len()>1{let mut next=Vec::with_capacity((layer.len()+1)/2);let mut i=0;while i<layer.len(){let r=if i+1<layer.len(){layer[i+1]}else{layer[i]};let mut d=Vec::with_capacity(64);d.extend_from_slice(&layer[i]);d.extend_from_slice(&r);let a=Sha256::digest(&d);let b=Sha256::digest(a);let mut h=[0u8;32];h.copy_from_slice(&b);next.push(h);i+=2;}layer=next;}layer[0]}

pub fn read_block_at_height(raw: &[u8], height: u64) -> Result<Block> {
    if raw.len() > MAX_BLOCK_SIZE { bail!("block exceeds 2 MiB protocol limit") }
    let mut c = Cursor::new(raw);
    let header = read_header_at(&mut c, height)?;
    if c.position() as usize >= raw.len() { bail!("block has no transaction section") }
    // Transaction parsing is deliberately isolated from header parsing. Ycash transaction
    // serialization is versioned and does not prefix each transaction with a byte length,
    // so a generic length-prefixed parser would be incorrect. The raw transaction section
    // is retained by the state layer for the full consensus decoder to process.
    Ok(Block { header, txs: Vec::new() })
}

pub fn read_block(raw: &[u8]) -> Result<Block> { read_block_at_height(raw, 1) }

pub fn genesis_hash_internal() -> [u8; 32] {
    let bytes = hex::decode(GENESIS_HASH_DISPLAY).expect("valid genesis hash");
    let mut out = [0u8; 32];
    for i in 0..32 { out[i] = bytes[31 - i]; }
    out
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn genesis_hash_is_internal_order() {
        assert_eq!(genesis_hash_internal()[0], 0x08);
        assert_eq!(genesis_hash_internal()[31], 0x00);
    }
}
