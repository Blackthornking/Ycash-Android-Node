//! Ycash Android Node v0.5 chain-state engine.
//!
//! This module implements deterministic chain metadata, cumulative-work
//! selection, fork discovery, and in-memory undo/rollback primitives.
//! Consensus validation remains an explicit caller boundary.

use std::collections::{BTreeMap, HashMap};

pub type Height = u32;
pub type Hash32 = [u8; 32];

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub struct BlockMeta {
    pub hash: Hash32,
    pub prev: Hash32,
    pub height: Height,
    pub chain_work: u128,
}

#[derive(Clone, Debug, Default)]
pub struct Undo {
    pub spent_utxos: Vec<(Vec<u8>, Vec<u8>)>,
    pub created_utxos: Vec<Vec<u8>>,
    pub added_nullifiers: Vec<Vec<u8>>,
}

#[derive(Debug)]
pub enum StateError {
    UnknownParent,
    InvalidHeight,
    WorkOverflow,
    UnknownTip,
}

pub struct ChainState {
    blocks: HashMap<Hash32, BlockMeta>,
    by_height: BTreeMap<Height, Vec<Hash32>>,
    undo: HashMap<Hash32, Undo>,
    best: Hash32,
    best_height: Height,
}

impl ChainState {
    pub fn new(genesis: BlockMeta) -> Self {
        let mut blocks = HashMap::new();
        let mut by_height = BTreeMap::new();
        let g = genesis;
        blocks.insert(g.hash, g);
        by_height.insert(g.height, vec![g.hash]);
        Self {
            blocks,
            by_height,
            undo: HashMap::new(),
            best: g.hash,
            best_height: g.height,
        }
    }

    pub fn best_tip(&self) -> Hash32 { self.best }
    pub fn best_height(&self) -> Height { self.best_height }

    pub fn insert_block(&mut self, meta: BlockMeta, undo: Undo) -> Result<bool, StateError> {
        let parent = self.blocks.get(&meta.prev).ok_or(StateError::UnknownParent)?;
        if meta.height != parent.height.saturating_add(1) {
            return Err(StateError::InvalidHeight);
        }
        if meta.chain_work < parent.chain_work {
            return Err(StateError::WorkOverflow);
        }
        self.blocks.insert(meta.hash, meta);
        self.by_height.entry(meta.height).or_default().push(meta.hash);
        self.undo.insert(meta.hash, undo);

        // Best chain is selected by greatest cumulative work; height breaks ties
        // deterministically so a node does not oscillate between equal-work tips.
        let cur = self.blocks.get(&self.best).unwrap();
        if meta.chain_work > cur.chain_work ||
           (meta.chain_work == cur.chain_work && meta.height > cur.height) {
            self.best = meta.hash;
            self.best_height = meta.height;
            return Ok(true);
        }
        Ok(false)
    }

    pub fn find_fork(&self, mut a: Hash32, mut b: Hash32) -> Option<Hash32> {
        while a != b {
            let ma = *self.blocks.get(&a)?;
            let mb = *self.blocks.get(&b)?;
            if ma.height > mb.height { a = ma.prev; }
            else if mb.height > ma.height { b = mb.prev; }
            else { a = ma.prev; b = mb.prev; }
        }
        Some(a)
    }

    pub fn path_back_to(&self, mut tip: Hash32, ancestor: Hash32) -> Option<Vec<Hash32>> {
        let mut path = Vec::new();
        while tip != ancestor {
            path.push(tip);
            tip = self.blocks.get(&tip)?.prev;
        }
        Some(path)
    }

    pub fn undo_for(&self, hash: &Hash32) -> Result<&Undo, StateError> {
        self.undo.get(hash).ok_or(StateError::UnknownTip)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn h(n: u8) -> Hash32 { [n; 32] }
    fn meta(hash:u8, prev:u8, height:u32, work:u128)->BlockMeta {
        BlockMeta { hash:h(hash), prev:h(prev), height, chain_work:work }
    }

    #[test]
    fn selects_greatest_cumulative_work() {
        let mut s=ChainState::new(meta(0,0,0,0));
        assert!(s.insert_block(meta(1,0,1,10),Undo::default()).unwrap());
        assert!(s.insert_block(meta(2,1,2,20),Undo::default()).unwrap());
        assert!(s.insert_block(meta(3,1,2,30),Undo::default()).unwrap());
        assert_eq!(s.best_tip(),h(3));
    }

    #[test]
    fn finds_common_ancestor() {
        let mut s=ChainState::new(meta(0,0,0,0));
        s.insert_block(meta(1,0,1,10),Undo::default()).unwrap();
        s.insert_block(meta(2,1,2,20),Undo::default()).unwrap();
        s.insert_block(meta(3,1,2,30),Undo::default()).unwrap();
        assert_eq!(s.find_fork(h(2),h(3)),Some(h(1)));
    }

    #[test]
    fn builds_rollback_path() {
        let mut s=ChainState::new(meta(0,0,0,0));
        s.insert_block(meta(1,0,1,10),Undo::default()).unwrap();
        s.insert_block(meta(2,1,2,20),Undo::default()).unwrap();
        assert_eq!(s.path_back_to(h(2),h(0)).unwrap(),vec![h(2),h(1)]);
    }
}
