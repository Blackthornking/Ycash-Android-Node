# Phase 11 — Live telemetry state wiring

The UI status endpoint is now backed by a shared Rust `LiveNodeState`.

Telemetry fields:
- running
- connected peer count
- locally committed block height
- downloaded/validated headers height
- target height (when known)
- derived sync percentage
- node diagnostic message

The Android UI also displays headers height.

Important: this is live runtime state, but this artifact still does not fabricate
a mainnet height. The P2P runtime must update the shared state as peers connect,
headers arrive, blocks validate, and chain state commits.

Next: connect the existing PeerManager/HeaderSync/ChainState implementations to
this state object and implement the complete mainnet sync loop.
