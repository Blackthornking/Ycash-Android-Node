# v0.8 Basic Android UI

A minimal native Android UI is included for early testing.

It currently provides:
- Ycash Android Node title/status
- Ycash Mainnet label
- peer/height/sync fields
- start/stop placeholders
- real TCP connectivity test to `seed.ycash.xyz:8833`
- basic connection logging

This UI does not claim that the Rust node is already synchronized. It is a test harness
for the networking layer. Full Rust node lifecycle and live sync telemetry will be wired
in the next phase.
