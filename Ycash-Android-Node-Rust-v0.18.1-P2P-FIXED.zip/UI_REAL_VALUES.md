# Real UI telemetry wiring — v0.9

The Android UI now polls the local node API:

GET http://127.0.0.1:8834/status

Expected JSON:
{
  "status": "running",
  "peers": 3,
  "height": 12345,
  "sync": "42%",
  "message": "syncing headers"
}

The Rust network crate defines the NodeStatus JSON contract.

The UI therefore no longer fabricates peer/height/sync values. Until the node's
HTTP server is running, the UI retains the last values and reports API unavailability.

Next integration step: expose the Rust NodeStatus through an actual localhost HTTP
listener owned by the node process and populate it directly from PeerManager and
ChainState. The Android UI should then display live values without any hardcoded
height or peer count.
